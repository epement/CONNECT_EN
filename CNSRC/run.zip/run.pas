{Virtual pascal source}
Program Run;

Uses
 VpSysLow, SysUtils, Strings, Dos;

type
 chars = array[0..1] of char;
 tStates = (Copy, Space, Tab, cr_lf, slash);

var
 State: tStates;
 Params: file;
 PrgName, ParamName, PrgPath, S: String;
 pComStr, pPath, pCmdLine: pchar;
 i, j, ParamSize, CmdSize, CmdLen: Longint;
 c: char;
 ExCode: Longint;


procedure Execute(const Path: PathStr; const ComLine: pchar);
var
  PathBuf: array[0..255] of Char;
begin
  ExCode := SysExecute(StrPCopy(PathBuf, Path),
    ComLine, nil, ExecFlags = efAsync, nil, -1, -1, -1);
end;

function GetEnvStr(const EnvVar: String): PChar;
var
  P: PChar;
  L: Word;
  EnvVarBuf: array [0..255] of Char;
begin
  StrPCopy(EnvVarBuf, EnvVar);
  L := Length(EnvVar);
  P := SysGetEnvironment;
  while P^ <> #0 do
  begin
    if (StrLIComp(P, EnvVarBuf, L) = 0) and (P[L] = '=') then
    begin
      Result := P + L + 1;
      Exit;
    end;
    Inc(P, StrLen(P) + 1);
  end;
  Result := nil;
end;

function GetPathStr(const pPath: Pchar; var i: longint): String;
var
 j: byte;
 SSS:String;
begin
 j := 0;
 while ((pPath+i)^ <> #0) do
  begin
   if ((pPath+i)^ <> ';') then
    begin
     inc(j);
     SSS[j] := (pPath+i)^;
     inc(i);
    end
   else
    begin
     inc(i);
     Break;
    end;
  end;
  if (j > 1) and (SSS[j] <> '\') then
   begin
    inc(j);
    SSS[j] := '\';
   end;
  SSS[0] := char(j);
  GetPathStr := SSS;
end;


begin
  ExCode := 1;
  if ParamCount < 2 then
   begin
    WriteLn('Win32 big command line programs runner. (C) Dmitry Orlov, 2005',
            #13#10'Run ProgramName ParamFile params');
    Halt(1);
   end;

  PrgName := ParamStr(1);
  if ExtractFileExt(PrgName) = '' then PrgName := Concat(PrgName, '.exe');
  if ExtractFileDir(PrgName) = '' then
   begin
    PrgPath := '';
    i := 0;
    pPath := GetEnvStr('PATH');

   { Executable file searching }
    while not FileExists(Concat(PrgPath, PrgName)) do
     begin
      PrgPath := GetPathStr(pPath, i);
      if PrgPath = '' then Break;
     end;
      PrgName := Concat(PrgPath, PrgName);
    end;

  if FileExists(PrgName) then
   begin
    ParamName := ParamStr(2);
    if FileExists(ParamName) then
    begin
      Assign(Params, ParamName);
      Reset(Params,1);
      CmdSize := StrLen(CmdLine);
      ParamSize := FileSize(Params)+CmdSize;
      if ParamSize < MaxAvail then
       begin
        GetMem(pComStr, ParamSize+2);
        BlockRead(Params, pComStr^, ParamSize);
        Close(Params);
        { Parameters processing }
        i := 0; j := 0;
        State := Copy;
        repeat
         c := (pComStr+j)^;
         if (c = #9) or (c = #10) or (c = #13) then
          begin
           (pComStr+j)^ := ' ';
           c := ' ';
          end;
         case State of
          Copy:  begin
                  if c >= ' ' then
                   begin
                    if i <> j then (pComStr+i)^ := (pComStr+j)^;
                    inc(i);
                   end;
                  inc(j);
                 end;
          Space: begin
                  while ((pComStr+j)^ <= ' ') or
                        ((pComStr+j)^ = '\') do inc(j);
                  State := Copy;
                 end;
         end;
         if (c = ' ') then State := Space;
        until j >= ParamSize;
        {Add command line}
        (pComStr+i)^ := ' ';
        inc(i);
        { Command line processing }
        pCmdLine := nil;
        if ParamCount > 2 then
         begin
          if CmdSize < MaxAvail then
           begin
            for j := 3 to ParamCount do
             begin
              S := ParamStr(j);
              Move(S[1], (pComStr+i)^, Length(S));
              inc(i, Length(S));
              (pComStr+i)^ := ' ';
              inc(i);
             end;
           end;
         end;
        (pComStr+i)^ := #0;
        Execute(PrgName, pComStr);
        FreeMem(pComStr);
       end;
    end;
   end;
  Halt(ExCode);
end.