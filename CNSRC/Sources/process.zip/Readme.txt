
                     Beyond Logic Process Monitor
                      http://www.beyondlogic.org
                     Craig.Peacock@beyondlogic.org

The Process Monitor is a quick Window's 2000 Driver to show the use of 
PsSetCreateProcessNotifyRoutine() which creates a callback that gets
called every time a process is created or terminated.

This program will send data to the debugger using KdPrint() showing
when a new process is created and it's details including image name,
Process ID and the Process' Address.

This driver demonstrates the use of the undocumented call,
PsLookupProcessByProcessId() to retrieve the Pointer to Process.

The Windows NT driver install utility at 
http://www.beyondlogic.org/dddtools/dddtools.htm can be used to install 
and remove the driver at run time.

Craig Peacock
11th June 2000

