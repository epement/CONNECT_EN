
//
// Process.C
// Craig.Peacock@beyondlogic.org
// http://www.beyondlogic.org
//
// Registers a ProcessNotifyRoutine using PsSetCreateProcessNotifyRoutine to
// display via a debugger, processes starting and finishing execution.
//
// Sunday 11th June 2000
//
//
// Additional Idea's 
//  + Prevent People Running Certain Applications
//  + Create a log of Applications Executed on a Machine.



#include <ntddk.h>

VOID NotifyNow (
    IN HANDLE  ParentId,
    IN HANDLE  ProcessId,
    IN BOOLEAN Create
    );

//
// Undocumentated Calls - PsLookupProcessByProcessId()
//
// Function :
//  Converts a ProcessID (ULONG) to a Pointer to Process.
//
// Usage :
//
//  ULONG ProcessID;	
//  struct _EPROCESS *Process;
//
//  PsLookupProcessByProcessId(ProcessID, &Process); 
//

NTSTATUS PsLookupProcessByProcessId(IN ULONG ulProcId, OUT struct _EPROCESS ** pEProcess);


VOID ProcessUnload(IN PDRIVER_OBJECT DriverObject)
{
	WCHAR DOSNameBuffer[] = L"\\DosDevices\\Process";
	UNICODE_STRING uniDOSString;

	// Remove Process Notify Callback
	PsSetCreateProcessNotifyRoutine(NotifyNow,1);

	KdPrint( ("PROCESS: Unloading . . .\n") );

	RtlInitUnicodeString(&uniDOSString, DOSNameBuffer);
	IoDeleteSymbolicLink (&uniDOSString);
	IoDeleteDevice(DriverObject->DeviceObject);
}


NTSTATUS ProcessCreateDispatch(
    IN  PDEVICE_OBJECT  DeviceObject,
    IN  PIRP            Irp
    )
{
	Irp->IoStatus.Information = 0;
	Irp->IoStatus.Status = STATUS_SUCCESS;
	IoCompleteRequest(Irp, IO_NO_INCREMENT);
	return STATUS_SUCCESS;
}


NTSTATUS DriverEntry(
    IN PDRIVER_OBJECT DriverObject,
    IN PUNICODE_STRING RegistryPath
    )
{
	PDEVICE_OBJECT deviceObject;
	NTSTATUS status;
	WCHAR NameBuffer[] = L"\\Device\\Process";
	WCHAR DOSNameBuffer[] = L"\\DosDevices\\Process";
	UNICODE_STRING uniNameString, uniDOSString;

	KdPrint( ("PROCESS: BeyondLogic Process Monitor Initialising\n"
                  "PROCESS: http://www.beyondlogic.org\n") );

	RtlInitUnicodeString(&uniNameString, NameBuffer);
	RtlInitUnicodeString(&uniDOSString, DOSNameBuffer);

	status = IoCreateDevice(DriverObject, 
				0,
				&uniNameString,
				FILE_DEVICE_UNKNOWN,
				0, 
				FALSE, 
				&deviceObject);

	if(!NT_SUCCESS(status))
		return status;

	status = IoCreateSymbolicLink (&uniDOSString, &uniNameString);

	if (!NT_SUCCESS(status))
		return status;

	PsSetCreateProcessNotifyRoutine(NotifyNow,0);

  	DriverObject->MajorFunction[IRP_MJ_CREATE] = ProcessCreateDispatch;
    	DriverObject->DriverUnload = ProcessUnload;

    	return STATUS_SUCCESS;
}



VOID NotifyNow(
    IN HANDLE  ParentId,
    IN HANDLE  ProcessId,
    IN BOOLEAN  Create
    )
{
	struct _EPROCESS *ProcessPointer;
        ULONG CurrentProcessId;
        char *CurProc;

	PsLookupProcessByProcessId((ULONG)ProcessId, &ProcessPointer);

	if (Create)
           {
  	    CurProc = (char *)ProcessPointer;
            CurProc += 0x1FC;
	    KdPrint( ("PROCESS: Process %s has been Created\n",CurProc) ); 
            KdPrint( ("PROCESS: ParentId = %d\n",ParentId) );
	    KdPrint( ("PROCESS: ProcessId = %d\n",ProcessId) );
            KdPrint( ("PROCESS: Process Address (PSLookup) = %x\n",ProcessPointer) );
           }
        else
            KdPrint( ("PROCESS: Process %d has terminated.\n",ProcessId) );

}
