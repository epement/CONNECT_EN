// See "dll_desc.txt" file for details

#ifndef C_ICPEXP_H
#define C_ICPEXP_H

#ifdef __cplusplus
extern "C" {
#endif

#ifdef  ICP_BUILD_DLL
#define DLL_FUNC __declspec(dllexport) __stdcall
#else
#define DLL_FUNC __declspec(dllimport) __stdcall
#endif

// ==================================================================
//     Standard Functions
// ==================================================================
// Starts application. Should be called once
// aFileCfg: ICP-01 configuration file to be loaded, usually "icp01.cfg"
int DLL_FUNC  IcpStartApplication (char *aFileCfg);

// ------------------------------------------------------------------
// Initializes RS-232 port (mandatory)
// aOverCfg:  0-gets communication parameters from *.cfg file
//            1-overrides *.cfg file with aPort and aBaudRate
// aPort:     0-COM1, 1-COM2,..., 6-COM7, 7-COM8
// aBaudRate: 0 - 38,400bps (programmers before June-2002)
//            1 - 115,200bps
int DLL_FUNC  IcpInitCom (int aOverCfg, int aComPort, int aBaudRate);

// ------------------------------------------------------------------
// Loads hex (mandatory) and serialzation file (optional)
int DLL_FUNC  IcpLoadHexAndSerFile (char *aFileHex, char *aFileSer);

// ------------------------------------------------------------------
// Executes action according ACTION_LIST
// aAction: see enum ACTION_LIST
// aMemorySpace: sum of memory space values for a function (see enum MEMORY_SPACES),
//               Example: set aMemorySpace=PM_SPACE+FU_SPACE to execute
//               an operation on program memory and configuration word
// aPmUserRange: 0-use full PM range from database, 1-override
// aPmAddrBeg:   start address of program memory (if aPmUserRange==1)
// aPmAddrEnd:   end address of program memory (if aPmUserRange==1)
// aSaveResult:  1-operation result will be written to file "auto01.res"
// aReadFile:    hex file to be saved after read operation

enum ACTION_LIST {
  ACT_PROG = 1, //programming
  ACT_VER  = 2, //verification
  ACT_READ = 3, //read
  ACT_BC   = 4, //blank check
};

enum MEMORY_SPACES {
  PM_SPACE = 0x0001, //program memory
  ID_SPACE = 0x0002, //ID locations
  DM_SPACE = 0x0004, //data memory
  CM_SPACE = 0x0008, //calibration memory (not supported)
  FU_SPACE = 0x0010, //configuration word
  LAST_SPACE = 0x0020
};

enum AUTO_ERROR_LEVEL { //return values
       AUTO_OK            = 0,  //operation OK
	   AUTO_DB_ERR        = 1,  //data base error
	   AUTO_COM_ERR       = 2,  //communication error
	   AUTO_VDD_ERR       = 3,  //Vdd overload error
	   AUTO_VPP_ERR       = 4,  //Vpp overload error
	   AUTO_HEX_ERR       = 5,  //HEX file loading error
	   AUTO_SER_ERR       = 6,  //serialization file error
	   AUTO_VER_ERR       = 7,  //verification error
	   AUTO_ERR_NO_SPACE  = 8,  //no space selected
	   AUTO_SAVE_ERR      = 9,  //file save error
	   AUTO_SOCK_ERR      = 10, //socket communication error (obsolete)
	   AUTO_I2C_ERR       = 11, //UUT I2C communication error
	   AUTO_DLL_ERR       = 12, //DLL programming is not supported
	   AUTO_KEY_ERR       = 13, //key generation error
	   AUTO_CFG_ERR       = 14, //config. file error
	   AUTO_COM_NUM_ERR   = 15, //invalid COM number
	   AUTO_COM_BUSY_ERR  = 16, //selected COM is busy
	   AUTO_COM_BAUD_ERR  = 17, //invalid baud rate
	   AUTO_COM_NO_OPEN   = 18, //can't open COM port
	   AUTO_USER_CANCEL   = 19, //user cancel
	   AUTO_IN_PROGRESS   = 20, //operation in progress
	   AUTO_BC_ERR        = 21, //blank check error
	   AUTO_OP_NOT_ALLOW  = 22, //operation not allowed
       AUTO_FW_INVALID    = 23, //firmware invalid - new download needed
       AUTO_24LC_ADDR_ERR = 24, //24LC01 address (offset) is out of range
       AUTO_DM_ADDR_ERR   = 25, //DM range error

	   AUTO_DEMO_ERR      = 101 //demo version
};


int DLL_FUNC  IcpDoAction( int aAction,
                  unsigned int aMemorySpace,
                  unsigned int aPmUserRange,
                  unsigned int aPmAddrBeg,
                  unsigned int aPmAddrEnd,
                  unsigned int aSaveResult,
                  char* aReadFile );
// ------------------------------------------------------------------
// Releases RS-232 port
int DLL_FUNC  IcpReleaseCom (void);

// ------------------------------------------------------------------
// Terminates application (mandatory). Should be called once
int DLL_FUNC  IcpEndApplication (void);

// ------------------------------------------------------------------
// Reads string with DLL version
int DLL_FUNC  IcpReadDllVersion (char *dllSoftwareVer);


// ==================================================================
//     Advanced Functions
// ==================================================================
// Gets actual PM range. May be useful for applications with simple GUI
int DLL_FUNC  IcpGetPmAddr(unsigned int *PmStart, unsigned int *PmEnd);

// ------------------------------------------------------------------
// Gets actual memory spaces selected for operations, see enum MEMORY_SPACES.
// May be useful for applications with simple GUI
int DLL_FUNC  IcpGetMemorySpace(unsigned int *CheckBox);

// ------------------------------------------------------------------
// Gets and sets communication parameters, overrides settings from icp01.cfg
// May be useful for applications with simple GUI.
// Parameters as for function IcpInitCom(...)
int DLL_FUNC  IcpGetCommParm(int *Port, int *baudRate);
int DLL_FUNC  IcpSetCommParm(int Port, int baudRate);

// ------------------------------------------------------------------
// Sets PIC DM (EEPROM) range for operation
// aDmUserRange: 0-use full DM range from database, 1-override
// aDmAddrBeg:   start address of data memory (if aDmUserRange==1)
// aDmAddrEnd:   end address of data memory   (if aDmUserRange==1)
int  DLL_FUNC IcpSetDmRange ( int aDmUserRange,
                              unsigned int aDmAddrBeg,
                              unsigned int aDmAddrEnd);

// ------------------------------------------------------------------
// Calculates unprotected checksum of the buffers according manufacturer's
// programming specifications.
unsigned DLL_FUNC  IcpCalcChecksum(void);

// ------------------------------------------------------------------
// Enables/disables progress window (progress bar)
void     DLL_FUNC  IcpEnableProgressWindow(int aEnable);

// ------------------------------------------------------------------
// Enables/disables sound by overriding "Sound" preferences
void DLL_FUNC IcpSetSound(int aSoundOn);

// ------------------------------------------------------------------
// Get current value of "Sound" preferences (0-disabled; 1-enabled)
int  DLL_FUNC IcpGetSound(void);

// ------------------------------------------------------------------
// Enables/disables chip erasing before programming by overriding
// "Clear flash device before programming" preferences
void DLL_FUNC IcpSetChipEraseBeforeProg(int aEraseOn);

// ------------------------------------------------------------------
// Saves or reads a byte to/from ICP-01 internal EEPROM 24LC01. May be used
// for secure applications
// NOTE: aOffset range: 0...(USER_BUF_SIZE_24LC01-1), i.e. 0...63

#define USER_BUF_SIZE_24LC01  64  //64 bytes of 24LC01 are available
int DLL_FUNC  IcpSaveByte24Lc01(unsigned char aOffset, unsigned char aData);
int DLL_FUNC  IcpReadByte24Lc01(unsigned char aOffset, unsigned char *aData);

// ------------------------------------------------------------------
// Turns ON/OFF the "sleep" setting for chip programming and reading
// operations. When this setting is ON, computer processor load is less,
// but the operations may execute slower.
// aTurnSleepOn: 0 - turn sleep off; 1 - turn sleep on
void DLL_FUNC IcpSetSleepOnWaitingRS232(int aTurnSleepOn);

// ------------------------------------------------------------------
// Provides full access to all ICP-1 buffers (PM, ID, DM, CM and FU)
// Be careful when modifying programming buffers.
// Suitable for applications that require buffer manipulation w/o using
// hex file
typedef struct {
	int      PmWordSize;     // Program Memory word size
	unsigned PmMaxWordVal;   // Program Memory maximal word value
    int      PmAddrUnit;     // Program Memory address unit:
                             //   1=show addresses in bytes; 2=in twobytes
	char *PmBuf; int PmSize; // Program Memory
	char *IdBuf; int IdSize; // ID Memory
	char *DmBuf; int DmSize; // Data Memory
	char *CmBuf; int CmSize; // Calibration Memory
	char *FuBuf; int FuSize; // Fuses Memory
} iBUFFERS;

void     DLL_FUNC  IcpGetBuffers (iBUFFERS *aBufs);

// ------------------------------------------------------------------
// aEnbl = 0 : update serialization file only after successful programming
// aEnbl = 1 : always update serialization file
void     DLL_FUNC  IcpAlwaysUpdateSer(int aEnbl);

#ifdef __cplusplus
}
#endif

#endif // C_ICPEXP_H


