lcc -DWIN32 about.c
lcc -DWIN32 accept.c
lcc -DWIN32 ansi.c
lcc -DWIN32 asdrv.c
lcc -DWIN32 config.c
lcc -DWIN32 line.c
lcc -DWIN32 menu.c
lcc -DWIN32 paint.c
lcc -DWIN32 progress.c
lcc -DWIN32 sioerror.c
lcc -DWIN32 term.c
lrc term.rc
lcclnk term.obj about.obj accept.obj ansi.obj asdrv.obj config.obj line.obj menu.obj paint.obj progress.obj sioerror.obj wsc32lcc.lib xym32lcc.lib mio32lcc.lib term.res -subsystem:windows
