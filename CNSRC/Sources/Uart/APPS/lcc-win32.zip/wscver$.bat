lcc -DWIN32 paint.c
lcc -DWIN32 wscver.c
lrc wscver.rc
lcclnk wscver.obj paint.obj wsc32lcc.lib wscver.res -subsystem:windows
