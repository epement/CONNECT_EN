lcc -DWIN32 console.c
lcc -DWIN32 sayerror.c
lcclnk console.obj sayerror.obj wsc32lcc.lib msvcrt.lib -subsystem:console
