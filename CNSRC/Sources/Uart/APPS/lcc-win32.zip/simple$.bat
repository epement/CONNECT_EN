lcc -DWIN32 sioerror.c
lcc -DWIN32 about.c
lcc -DWIN32 line.c
lcc -DWIN32 paint.c
lcc -DWIN32 simple.c
lrc simple.rc
lcclnk simple.obj paint.obj sioerror.obj about.obj line.obj wsc32lcc.lib simple.res -subsystem:windows
