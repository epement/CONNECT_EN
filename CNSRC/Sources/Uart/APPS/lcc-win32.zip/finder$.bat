lcc -DWIN32 finder.c
lcclnk finder.obj wsc32lcc.lib -subsystem:console
