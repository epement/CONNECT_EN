#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include "rdlawson.h"
#include <string.h>
#include <windows.h>
#include <winbase.h>

#define WINAPI __stdcall

int __stdcall convert_file(char *, char *);

/*
char infile[] = "ST480.S05";
char outfile[] = "test.seq";

void main()
{
  convert_file(infile,outfile);
}
*/

int __stdcall convert_file(char *infile , char *outfile )
{
  long x,fpos;
  int buf;
  int fname_len;
  char fext[3];
  int seq = 0;
  int lampbuf[2];
  char temp[40];
  int n = 0;
  int a,b,c,d;
  int lamp,line;
  unsigned int coil;
  int lampsfound = 0;
  int endflag = 0;

  FILE *fptr;
  FILE *fptr2;

  fname_len = strlen(infile);
  fext[0] = infile[fname_len -1];
  fext[1] = infile[fname_len];
  fext[2] = '\0';


  seq = atoi(fext);

  if ((fptr = fopen(infile,"rb")) == NULL )
  {
    exit(1);
  }

  if ((fptr2 = fopen(outfile,"w")) == NULL )
  {
    exit(1);
  }




    do
    {

      buf = fgetc(fptr);

      if(buf == 0x82)
   lampsfound = 1;

    /*  if(buf == 0x83)
	endflag = 1;
                       */

      if(buf == 0x83)
      {
		buf = fgetc(fptr);
		if(buf == 0x6e)	
     	  endflag = 1;
	  }


      if ((buf == 0x03) && lampsfound && !endflag)
	  {

	    buf = fgetc(fptr);
	    while(!isalnum(buf))
	      buf = fgetc(fptr);




	    if(buf >= 32 && buf <= 127)
	    {
	      fseek(fptr,-4,SEEK_CUR);
	      buf = fgetc(fptr);
	      lampbuf[0] = buf;

	      buf = fgetc(fptr);
	      lampbuf[1] = buf;


      /*      ab  cd     needs converting to */
      /*                                     */
      /*      da  cb + 1                     */

	      a = lampbuf[0] & 0x00F0;
	      b = lampbuf[0] & 0x000F;
	      c = lampbuf[1] & 0x00F0;
	      d = lampbuf[1] & 0x000F;

	      d = d << 4;
	      a = a >> 4;

	      lampbuf[0] = a | d;
	      b = b + 1;
	      lampbuf[1] = c | b;

	      line = lampbuf[0];
	      lamp = lampbuf[1];

	      coil = (line * 16) + (lamp -1);
	      coil = coil + sequences[seq];

	      fprintf(fptr2,"%06d",coil);
	      fprintf(fptr2,"%c",' ');
	      fprintf(fptr2,"%c",',');

	      fprintf(fptr2,"%c",' ');
	      fprintf(fptr2,"%2d",line);
	      fprintf(fptr2,"%c",',');
	      fprintf(fptr2,"%c",' ');
	      fprintf(fptr2,"%2d",lamp);
	      fprintf(fptr2,"%c",' ');
	      fprintf(fptr2,"%c",',');
	      fprintf(fptr2,"%c",' ');




	      buf = fgetc(fptr);
	      buf = fgetc(fptr);

	      while(buf >= 32 && buf <= 127)
	      {

		fprintf(fptr2,"%c",buf);
		buf = fgetc(fptr);
	      }

	   /* print input numbers etc */

	     while(buf  == 0)
	      buf = fgetc(fptr);



	     while(buf >= 32 && buf <= 127 )
	      {
		temp[n] = buf;
		buf = fgetc(fptr);
		n++;
	      }

	      if(n >= 4)
	      {
		temp[n] = '\0';
		fprintf(fptr2,"%c%s",',',temp);
		n = 0;
	      }


	      fprintf(fptr2,"%c",'\n');

	    }
	  }



      }while(!feof(fptr));



   fclose(fptr);
   fclose(fptr2);

}