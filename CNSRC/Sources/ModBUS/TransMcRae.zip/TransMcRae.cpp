
#include <stdio.h>
#include <windows.h>

#define FALSE 0
#define TRUE  1


/* This program is a D. Urda translation for Win32 Console Aplication from
/* a simple demo for Linux by P. MCRae to read holdings register from a modicon
/* 984 plc, via a rs232 serial port. Mainly Changes: Comm1, Even Parity, Timeout

/* paul@pmcrae.freeserve.co.uk (http://www.pmcrae.freeserve.co.uk/)
/* durda@step.es (http://www.step.es/personales/durda/)

int set_up_comms(void);

unsigned int crc (unsigned char buf[], int start, int cnt);

int read_hold_reg(int slave, int com_port, int baud, char parity,
								int timeout, int offset, int num_regs, int *reg_table);

BOOLEAN charsinqueue();


int result;

WORD flags;

HANDLE hPort;
DCB tnew, tsaved; /* DCB (device control block) structs */
int table[100];

/******************************************************************************/
/************************* MAIN PROGRAM ***************************************/
/******************************************************************************/

int main()
{

int tabindex;

/* setup communications parameter */

set_up_comms();

/* Read a table of 65 register from plc address 1 holding register 400101 */

result =read_hold_reg(1,1,9600,'E',2000,101,5, table);

if (result == FALSE) /* if no comms errors */
	{
   for(tabindex=0; tabindex < 5; tabindex++)
   	{
      printf("%d\n", table[tabindex]);
      }
   }

SetCommState(hPort, &tsaved); // Reset comms param to old values

CloseHandle(hPort); // Close comms chanel

getchar();

}

/************************ END MAIN PROGRAM ************************************/


/************************** THE FUNCTIONS  ************************************/

/*****************************************************************************/
/***************** [ BEGIN: READ_HOLD_REG ] **********************************/
/*****************************************************************************/


int read_hold_reg(int slave, int com_port, int baud, char parity,
					int timeout, int reg_num, int num_regs, int *reg_table)

{

/* Define and Initialice variables */

	int byte_count;
   int bytes_required = 5 + (num_regs * 2); // 2 * reg read + 5 bytes header
   int bytes_received = 0;
   int function = 3;						/* set code to read holding registers */
   int offset = reg_num -1;
   unsigned short crc_calc = 0;
   unsigned short crc_received = 0;
   unsigned int temp;
   int i;
   int error_flag;
   unsigned char recv_crc_hi;
   unsigned char recv_crc_lo;
   char rxchar = -1;
   unsigned char query[8];
   unsigned char recv[1024];
   unsigned char offset_hi = offset >> 8;  /* split offset into hi & lo bytes */
   unsigned char offset_lo = offset & 0x00FF;
   unsigned char crc_lo ;
   unsigned char crc_hi ;
   unsigned char numreg_hi = num_regs >> 8; /* split numregs into hi & lo bytes */
   unsigned char numreg_lo = num_regs & 0x00FF;
   DWORD start, now, elapsed_time;


   DWORD dwErrorCode;
   DWORD dwcharswritten;
   DWORD dwcharsreaded;

   query[0] = slave;			/* plc address */
   query[1] = function;		/* modbus function code to read holding register */
   query[2] = offset_hi;	/* base address of register table, Hi byte */
   query[3] = offset_lo;   /* base address of register table, Lo byte */
   query[4] = numreg_hi;	/* num of registers to read, Hi byte */
   query[5] = numreg_lo;	/* num of registers to read, Lo byte */

   temp = crc(query,0,6);	/* Calculate 16 bit CRC on query message */
   crc_hi = temp >> 8;
   crc_lo = temp & 0x00FF;

   query[6] = crc_hi;
   query[7] = crc_lo;
   query[8] = NULL;



/************* Communication setup ********************************************/

/* hPort = setup_comms(com_port, baud, parity);
** Paul B. McRae says: function to be finished when I've got time.
*/

/********************* send message to slave **********************************/
/* Translation for Win 32 APIs by D. Urda */

PurgeComm(hPort, PURGE_RXCLEAR); //ACTION 8 -> Clear serial input buffer
											// without transmit content
PurgeComm(hPort, PURGE_TXCLEAR); //ACTION 4 -> Clear serial output buffer
                                 // without transmit content
dwcharswritten =0;

WriteFile(hPort, query, 8, &dwcharswritten, NULL); //send message to slave

PurgeComm(hPort, PURGE_RXCLEAR); // Clear serial input buff..., one more time.

start = GetTickCount(); /*** save time when message was sent to slave *********/

/***************** Get slave response *****************************************/

bytes_received=0;
while (bytes_received < bytes_required){
	if (charsinqueue() >0)
   	{
      ReadFile(hPort, &rxchar, 1, &dwcharsreaded, NULL);
      if (rxchar != -1)
      	{
      		recv[bytes_received] = rxchar;
         	printf("%s%d\n", "char rx ", rxchar);
         	bytes_received++;
         	printf("%s%d\n", "bytes received ", bytes_received);
      	}
      }
   now= GetTickCount();
   elapsed_time= now - start;
   if (elapsed_time > 2000)
   	{
   		printf("timeout \n");
      	error_flag = TRUE;
         break;
      }
   } //end while

if (error_flag)
	return(TRUE);  //If comm timeout is TRUE, exit from READ_HOLD_REG

/***************** Decode response from PLC ***********************************/
if (bytes_required == bytes_received)
{
	crc_calc = crc(recv, 0, bytes_received -2);

   recv_crc_hi = (unsigned) recv[bytes_received -2];
   recv_crc_lo = (unsigned) recv[bytes_received -1];

   crc_received = recv[bytes_received -2];
   crc_received = (unsigned) crc_received << 8;
   crc_received = crc_received | (unsigned) recv[bytes_received -1];

   if (crc_calc != crc_received)
   {
   	printf("crc error \n");
      printf("%s%x\n","crc_received ", crc_received);
      printf("%s%x\n","crc_calc ", crc_calc);

      error_flag = TRUE;
   }
}

/*************** Check for exception response *********************************/
	if (bytes_received < bytes_required)
	{
		if (recv[1] != function)
   	{
    	printf("exception response \n");
    	error_flag = TRUE;
   	}
	}

/************** Extract data part of message from PLC *************************/
	if (error_flag == FALSE)
	{
		for (i=0; i< num_regs; i++)
   	{
   		temp = recv[3 + i*2] << 8;		//shift reg hi_byte to temp
      	temp = temp | recv[4 + i*2];	// OR with lo_byte
      	reg_table[i] = temp;
   	}
	}
	if (error_flag)
	{
		return TRUE;
	}
	else
	{
	return FALSE;
	}

}
/***************** [ END: READ_HOLD_REG ] ************************************/


/*****************************************************************************/
/***************** [ BEGIN: set_up_comms ] ***********************************/
/*****************************************************************************/

/* Routine translated from Linux to Win32 by D. Urda. Only Win32 Serial Comms
	API functions are used for Win 9X, Me, NT and 2000 full compability.
*/

int set_up_comms()
{
hPort = CreateFile("COM1",GENERIC_READ | GENERIC_WRITE,
						0,
						NULL,
						OPEN_EXISTING,
						FILE_ATTRIBUTE_NORMAL,
						NULL
						);

if (hPort == INVALID_HANDLE_VALUE)
	{
	CloseHandle(hPort);
	printf("invalid");
	getchar();
	}
else
printf("the port%d \n", hPort);
if (GetCommState(hPort, &tsaved) == TRUE); /* Saving prev conf */
	{                                       /* New conf values */
   tnew.BaudRate = 9600;
   tnew.ByteSize = 8;
   tnew.Parity = EVENPARITY;
   tnew.StopBits = ONESTOPBIT;

   DWORD *tnew_Flags= &(tnew.BaudRate) +1; //Pointer to DWORD with flags set.
     *tnew_Flags = 1; //Setting DCB binary flag ON, all others OFF, in one step

   SetCommState(hPort, &tnew); //Setting new conf //
   }
}

/***************** [ END: set_up_comms ] **************************************/


/*****************************************************************************/
/***************** [ BEGIN: crc ] ********************************************/
/*****************************************************************************/
/*
INPUTS:
	buf   -> Array containing message to be sent to controller.
   start -> Start of loop in crc counter, usually 0.
   cnt   -> Amount of bytes in message being sent to controller.
OUTPUTS:
	temp  -> Return crc byte for message.
COMMENTS:
	This routine receives the data message to be sent down to the controller
*/

unsigned int crc(unsigned char buf[], int start, int cnt)
{
	int 	i,j;
   unsigned temp, temp2, flag;

   temp=0xFFFF;

   for (i=start; i<cnt; i++){
   	temp=temp ^ buf[i];

      for (j=1; j<=8; j++){
      	flag=temp & 0x0001;
         temp=temp >> 1;
         if (flag) temp=temp ^ 0xA001;
         }
      }
   /*** Reverse byte order. ***/
   temp2=temp >> 8;
   temp= (temp << 8) | temp2;
   return(temp);
}
/***************** [ END: crc ] ***********************************************/

/***************** [ Paul B. McRae says] **************************************/
//Please note: There should be a gap of at least 20ms betwen multiple modbus
// messages as comms errors can result this been omited for simplicity.
//I will try and find the time to correct this but the aim of this little project
// was to try and spark off other peoples interest in producing linux software
// for modbus and not produce a perfect system as I don't have the time


/***************** [ BEGIN: charsinqueue ] ************************************/
/* Comment: D. Urda has implemented this function for avoid PC has waiting chars
 on serial comm input queue, when the communication with the slave fails.
 (There are no hardware handshake). */

BOOLEAN charsinqueue()
{
COMSTAT StatPort;
DWORD dwErrorCode;


ClearCommError(hPort, &dwErrorCode, &StatPort);   //API WIN32
return (StatPort.cbInQue);
if (StatPort.cbInQue != 0)
	return FALSE; //There are no characters in queue.
else
	return TRUE;  //At least one character in queue.

}
/******************************* [ END: charsinqueue ] ************************/



