This is only a prototype so use at your own risk!
There is no warranty of any kind and I accept no responsibilty for its use or missuse
or effects on your companies credibility. This is something I have produced for my own 
interest and wish to share with others.

This is a free msvc++ dynamic library for reading a single 984 modicon plc holding register .
The function is written in 'c' and is called thus :-


Note that regoffset is the register number with the leading 4xxxx left off.
eg 40102 is sent to function as 102.

prototype int read_hold_reg(int regoffset, int slave ,int port, int baud, int parity);

please note for the parity parameter.

0 = noparity
1 = oddparity
2 = evenparity


example call read_hold_reg(102,1,1,9600,2);


to use from visual basic

put the dll rxmod.dll in the directory c:\com32

declare this function in your form declaration area
 
Private Declare Function read_hold_reg Lib "c:\com32\rxmod.dll" _
(ByVal regnum As Integer ,ByVal slave As Integer, ByVal port As Integer,
  ByVal baud As Integer , ByVal parity As Integer) As Integer


example call from vb

Private Sub Command1_Click()
Dim result As Integer
result = read_hold_reg(102,1,1,9600,2)
Text1.Text = result
End Sub



 




To compile for c++ put the .lib and dll in the same directory as you source files
and include them in your project.

------------------------------------------------------------------------
Please Email me on pbmcrae42@yahoo.com if you found it useful.

I am currently employed as an electrical technician with a large car manufacturer
but I would be interested in a career move if the right opportunity came up
so if you think you have a challeging role within the control engineering / software
field please feel free to contact me. 







This is only a prototype so use at your own risk !.
                              
