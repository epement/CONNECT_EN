   =========================================================================
                              Micro Focus

                          N E T E X P R E S S   
   =========================================================================
                              PROJECT ATTRIB
                              ===============

   DATE CREATED:
   =============

   BUILD W/RELEASE:  Net Express v3.1 with fixpacks as of 05/2002.
   ================

   TABLE OF CONTENTS
   =================
       INTRODUCTION
       SOURCE FILES
       REQUIREMENTS
       OPERATION


   INTRODUCTION
   ============

	This demo show how to use the usage of the GetFileAttributes and 
	SetFileAttributes APIs.  This sample will set a file as Read-Only.

   SOURCE FILES:
   =============

	Program Files	Description
	=============	=============================================

	fileattribute.cbl

	
   REQUIREMENTS:
   =============


   OPERATION:
   ==========
	Rebuild and animate program.


   NOTE:
   =====


