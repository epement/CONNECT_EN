      $set ans85 mf defaultbyte"00" case
       copy "winerror.cpy".
       copy "windows.cpy".
       identification division.
       program-id. fileattribute.
       special-names.
           call-convention 74 is WINAPI.

       data division.
       working-storage section.
      *copy "miniwin.cpy".
       copy "wintypes.cpy".

       01  ws-attributes               DWORD.
       01  ws-READONLY                 DWORD
                                       value FILE-ATTRIBUTE-READONLY.

       procedure division.

           display erase
      *
      ***** Get File Attributes
      *
           call WINAPI GetFileAttributes using
                by reference z".\fileattribute.cbl"
                returning ws-attributes
           end-call

      ***** Make the file READONLY

           display "Setting the file READONLY"
           add FILE-ATTRIBUTE-READONLY to ws-attributes
           call WINAPI SetFileAttributes using
                by reference z".\fileattribute.cbl"
                by value ws-attributes
           end-call

           display "Checking if file READONLY"
           call WINAPI GetFileAttributes using
                by reference z".\fileattribute.cbl"
                returning ws-attributes
           end-call

           call "CBL_AND" using ws-readonly
                                ws-attributes
                       by value 4 size 4.

           if ws-attributes > 0
               display "   File is READONLY"
           else
               display "   File is NOT READONLY"
           end-if

           display "Remove READONLY"

           call WINAPI GetFileAttributes using
                by reference z".\fileattribute.cbl"
                returning ws-attributes
           end-call

           subtract FILE-ATTRIBUTE-READONLY from ws-attributes
           call WINAPI SetFileAttributes using
                by reference z".\fileattribute.cbl"
                by value ws-attributes
           end-call


           stop run
           .
