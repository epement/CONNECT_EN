       Identification Division.
       Program-ID.  VersionNo.
       Data Division.

       Working-Storage Section.
       Procedure Division.
       0000-Main.
           stop run.
