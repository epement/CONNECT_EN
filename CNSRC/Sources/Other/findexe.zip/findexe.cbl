      $set mf defaultbyte"00" case
      *----------------------------------------------------------------*
      *                          FINDEXE                               *
      *                                                                *
      *  This sample program demonstrates how to find the executable   *
      *  program name which is associated with a particular file       *
      *  extension and then use it to open the specified file.         *
      *  File associations are made in Windows Explorer under the File *
      *  Types option. This example uses the filename DUMMY.CBL which  *
      *  is associated with Net Express when it is installed.          *
      *----------------------------------------------------------------*
       id division.
       program-id.  findexe.
       special-names.
           call-convention 74 is WINAPI.
       data division.
       working-storage section.
       copy "miniwin.cpy".
       copy "wintypes.cpy".
       copy "winuser.cpy".
       copy "winbase.cpy".

      *** Parameters for CreateProcess call.

       01  startup-info             STARTUPINFOA.
       01  process-info             PROCESS-INFORMATION.
       01  ws-okay                  BOOL.
       01  ws-app-return-code       DWORD.
       01  ws-command-line          pic x(1024)      value spaces.

       01  ret-code                 pic s9(9) comp-5 value zeroes.
       01  lpFileName               pic x(255)       value z"DUMMY.CBL".
       01  associated-exe-name      pic x(255)       value spaces.
       procedure division.
       000-begin.

      ***  This call will return the full path name to the executable
      ***  which is associated with the file extension ".CBL".
      ***  In this case it should be Net Express.

           call WINAPI "FindExecutableA"
              using by reference lpFileName *> .CBL in current dir
                    by value 0              *> no start directory
                    by reference associated-exe-name *> returned info
              returning ret-code
           end-call
           if ret-code > 32 *> return of <= 32 is an error.
              string associated-exe-name delimited by x"00"
                 " " delimited by size
                 lpFileName delimited by size
                 into ws-command-line *> used in CreateProcess
              end-string
              perform 100-create-process
           else
              display "Error on FindExecutable = " ret-code
           end-if
           stop run.

      *----------------------------------------------------------------*

       100-create-process.

            move length of startup-info to cb of startup-info
            move SW-NORMAL to wshowwindow of startup-info

            call WINAPI "CreateProcessA"
               using by value 0 *> application name is NULL.
                     by reference ws-command-line *> program to execute
                     by value 0
                     by value 0
                     by value 0 *> open handles not inherited.
                     by value CREATE-DEFAULT-ERROR-MODE
                     by value 0 *> use parents environment.
                     by value 0 *> current working directory
                     by reference startup-info
                     by reference process-info
               returning ws-okay
            end-call

            if ws-okay = isTRUE
               call WINAPI "WaitForSingleObject"
                  using by value hProcess of process-info
                        by value INFINITE   *> No timeout
                  returning ws-okay
               end-call
            else
               display "CreateProcess error = " ws-okay
            end-if.

