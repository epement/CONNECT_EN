       id division.
       program-id.  dummy.
       data division.
       working-storage section.
       01  ws-dummy-param             pic x(20)         value spaces.
       procedure division.
       000-begin.

           display "Net Express should have loaded this program"
           display "Close this session to return to the Original."
           stop run.

