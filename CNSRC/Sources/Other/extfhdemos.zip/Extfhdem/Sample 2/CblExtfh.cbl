      $ set Ans85 Mf"10" NoOsvs NoVsc2 DefaultByte"00"
       working-storage section.
       78  programName                                 value 'CblExtfh'.
           copy CblExtfh.cpy.
           copy CblFcdLs.cpy.
       procedure division.
           display programName ': Starting.'
           display programname ': Creating Line Sequential File.'
           set fcdExtfhOpCodeIsOpenOutput      to True
           set fcdOrganizationLineSequential   to True
           set fcdAccessSequential             to True
           set fcdFileIsClosed                 to True
           move length of wsLineSequentialFileName to fcdNameLength
           set fcdLockModeIsExclusive          to True
           set fcdOtherFlagsIsNone             to True
           set fcdFileFormatIsThisSystem       to True
           move length of wsLineSequentialRecordArea to fcdMaxRecLength
           set fcdRecordingModeIsVariable      to True
           move 0 to fcdMinRecLength
           set fcdFileNameAddress to address of wsLineSequentialFileName
           set fcdDataCompressIsNone           to True
           set fcdLockTypesIsNone              to True
           perform callEXTFH
           perform fcdFSCheck
           if fcdFS = '00'
             display programName
                 ': Line Sequential File is Open Output.'
             perform with test after varying wsLSRTX from 1 by 1
                 until wsLSRTX = wsLSRTCount or fcdFS <> '00'
               set fcdExtfhOpCodeIsWrite       to True
               move wsLSRTELength(wsLSRTX) to fcdCurrentRecLength
               move 1 to fcdLineCount
               set fcdRecordAddress to address of wsLSRTEData(wsLSRTX)
               perform callEXTFH
               perform fcdFSCheck
             end-perform
             if fcdFS = '00'
               display programName ': Line Sequential Writes complete.'
               set fcdExtfhOpCodeIsClose       to True
               perform callEXTFH
               perform fcdFSCheck
               if fcdFS = '00'
                 display programName ': Line Sequential File is Closed.'
               else
                 display programName
                     ': Unable to Close Line Sequential File.'
               end-if
             else
               display programName
                   ': Unable to create Line Sequential File.'
             end-if
           else
             display programName
                 ': Unable to Open Line Sequential File as Output.'
             stop run
           end-if
           display programName ': Reading Line Sequential File.'
           set fcdExtfhOpCodeIsOpenInput       to True
           set fcdOrganizationLineSequential   to True
           set fcdAccessSequential             to True
           set fcdFileIsClosed                 to True
           move length of wsLineSequentialFileName to fcdNameLength
           set fcdLockModeIsExclusive          to True
           set fcdOtherFlagsIsNone             to True
           set fcdFileFormatIsThisSystem       to True
           move length of wsLineSequentialRecordArea to fcdMaxRecLength
           set fcdRecordingModeIsVariable      to True
           move 0 to fcdMinRecLength
           set fcdFileNameAddress to address of wsLineSequentialFileName
           set fcdDataCompressIsNone           to True
           set fcdLockTypesIsNone              to True
           perform callEXTFH
           perform fcdFSCheck
           if fcdFS = '00'
             display programName
                 ': Line Sequential File is Open Input.'
             perform with test after until fcdFS <> '00'
               set fcdExtfhOpCodeIsReadSequential  to True
               set fcdRecordAddress
                to address of wsLineSequentialRecordArea
               perform callEXTFH
               perform fcdFSCheck
               if fcdFS = '00'
                 display programName
                     ': Record = ' wsLineSequentialRecordArea
                                   (1:fcdCurrentRecLength)
               end-if
             end-perform
             if fcdFS = '00' or '10'
               display programName ': Line Sequential Reads complete.'
               set fcdExtfhOpCodeIsClose       to True
               perform callEXTFH
               perform fcdFSCheck
               if fcdFS = '00'
                 display programName ': Line Sequential File is Closed.'
               else
                 display programName
                     ': Unable to Close Line Sequential File.'
               end-if
             else
               display programName
                   ': Unable to Read Line Sequential File.'
             end-if
           else
             display programName
                 ': Unable to Open Line Sequential File as Input.'
             stop run
           end-if
           display programName ': Ending.'
           stop run.
       callEXTFH.
           call 'EXTFH' using fcdOpCode, fcdParameterBlock.
       fcdFSCheck.
           if fcdFS1 = '9'
             display programName ': Run-time error 9/' fcdRTE
           else
             if fcdFS <> '00'
               display programName ': File Status = ' fcdFS
             else
               continue
             end-if
           end-if.
