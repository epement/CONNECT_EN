       1   fcdOpCode.
           2   filler              pic x               value x'FA'.     DfltStnd
           2   fcdExtfhOpCode      pic x.                               FileType
      *    Standard Operation Codes
           88  fcdExtfhOpCodeIsOpenInput               value x'00'.     L S R I
           88  fcdExtfhOpCodeIsOpenOutput              value x'01'.     L S R I
           88  fcdExtfhOpCodeIsReadSequential          value x'8D'.     L S R I
           88  fcdExtfhOpCodeIsClose                   value x'80'.     L S R I
           88  fcdExtfhOpCodeIsWrite                   value x'F3'.     L S R I
      *    Special Operation Codes
       1   fcdParameterBlock.                       *> offset length
           2   fcdFS.                                   *>  0 2
               3   fcdFS1          pic x.               *>  0 1
               3   fcdFS2          pic x.               *>  1 1
               3   fcdRTE          redefines   fcdFS2
                                   pic x       comp-x.  *>  1 1
           2   filler              pic xxx.             *>  2 3
           2   fcdOrganization     pic x       comp-x.  *>  5 1
           88  fcdOrganizationLineSequential           value 0.
           2   fcdAccessMode       pic x       comp-x.  *>  6 1
           88  fcdAccessSequential                     value 0.
           2   fcdOpenMode         pic x       comp-x.  *>  7 1
           88  fcdFileIsClosed                         value 128.
           2   filler              pic xxx.             *>  8 3
           2   fcdNameLength       pic xx      comp-x.  *> 11 2
           2   filler              pic x(9).            *> 13 9
           2   fcdTransLog         pic x       comp-x.  *> 22 1
           2   filler              pic x.               *> 23 1
           2   fcdLockMode         pic x       comp-x.  *> 24 1
           88  fcdLockModeIsExclusive                  value 1.
           2   fcdOtherFlags       pic x       comp-x.  *> 25 1
           88  fcdOtherFlagsIsNone                     value 0.
           2   filler              pic xx.              *> 26 2
           2   fcdHandle                       pointer. *> 28 4
           2   filler              pic x.               *> 32 1
           2   fcdStatusType       pic x       comp-x.  *> 33 1
           2   fcdFileFormat       pic x       comp-x.  *> 34 1
           88  fcdFileFormatIsThisSystem               value 3.
           2   filler              pic xxx.             *> 35 3
           2   fcdMaxRecLength     pic xx      comp-x.  *> 38 2
           2   filler              pic xxx.             *> 40 3
           2   fcdRelativeKey      pic xxxx    comp-x.  *> 43 4
           2   fcdRecordingMode    pic x       comp-x.  *> 47 1
           88  fcdRecordingModeIsVariable              value 1.
           2   fcdCurrentRecLength pic xx      comp-x.  *> 48 2
           2   fcdMinRecLength     pic xx      comp-x.  *> 50 2
           2   fcdKeyId            pic xx      comp-x.  *> 52 2
           2   fcdLineCount        redefines   fcdKeyId
                                   pic xx      comp-x.  *> 52 2
           2   fcdKeyLength        pic xx      comp-x.  *> 54 2
           2   fcdRecordAddress                pointer. *> 56 4
           2   fcdFileNameAddress              pointer. *> 60 4
           2   fcdKeyDefAddress                pointer. *> 64 4
           2   filler              pic x(4).            *> 68 4
           2   fcdRelAddrOffset    pic xxxx    comp-x.  *> 72 4
           2   filler              pic xx.              *> 76 2
           2   fcdDataCompress     pic x       comp-x.  *> 78 1
           88  fcdDataCompressIsNone                   value 0.
           2   fcdSessionId        pic xxxx    comp-x.  *> 79 4
           2   fcdFSFileId         pic xx      comp-x.  *> 83 2
           2   fcdMaxRelKey        pic xxxx    comp-x.  *> 85 4
           2   fcdFlags1           pic x       comp-x.  *> 89 1
           2   fcdBlocking         pic x       comp-x.  *> 90 1
           2   fcdLockTypes        pic x       comp-x.  *> 91 1
           88  fcdLockTypesIsNone                      value 0.
           2   fcdFSFlags          pic x       comp-x.  *> 92 1
           2   fcdConfigFlags      pic x       comp-x.  *> 93 1
           2   filler              pic x.               *> 94 1
           2   fcdConfigFlags2     pic x       comp-x.  *> 95 1
           2   fcdIDXCacheSize     pic x       comp-x.  *> 96 1
           2   fcdIDXCacheBufs     pic x       comp-x.  *> 97 1
           2   filler              pic xx.              *> 98 2
