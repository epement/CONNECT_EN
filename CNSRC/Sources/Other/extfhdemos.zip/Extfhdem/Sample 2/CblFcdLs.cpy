       1   wsLineSequentialFileName   pic x(12)  value 'fcdls.dat'.
       1   wsLineSequentialRecordArea pic x(255).
       1   wsLineSequentialRecords.
           2   wsLSRCount             pic x    comp-x  value 3.
           2   wsLSRecord1.
               3   wsLSR1Length       pic x    comp-x  value 22.
               3   wsLSR1Data         pic x(80)
               value 'Mary had a little lamb'.
           2   wsLSRecord2.
               3   wsLSR2Length       pic x    comp-x  value 33.
               3   wsLSR2Data         pic x(80)
               value 'Red Riding Hood had a GrandMother'.
           2   wsLSRecord3.
               3   wsLSR3Length       pic x    comp-x  value 22.
               3   wsLSR3Data         pic x(80)
               value 'The Fox had Big Teeth!'.
       1   wsLineSequentialRecordTable
               redefines wsLineSequentialRecords.
           2   wsLSRTCount            pic x    comp-x.
           2   wsLSRTEntry            occurs 3 times
                                      indexed by wsLSRTX.
               3   wsLSRTELength      pic x    comp-x.
               3   wsLSRTEData        pic x(80).
