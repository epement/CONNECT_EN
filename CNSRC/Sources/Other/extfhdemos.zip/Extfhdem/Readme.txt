   =========================================================================
                              Micro Focus

                          N E T E X P R E S S   
   =========================================================================
                       PROJECT Callable File Handler
                       =============================

   DATE CREATED:	Reviewed 05/2002
   =============

   BUILD W/RELEASE:  Net Express v3.1 with fixpacks as of 05/2002
   ================

   TABLE OF CONTENTS
   =================
       INTRODUCTION
       OPERATION
       NOTE	


   INTRODUCTION
   ============

	This demo demonstrate how the File Handler, EXTFH can be called directly.

   OPERATION:
   ==========

	The zip file consist of 2 samples, one showing how to read and write to 
	an index file while the other shows how you can create and read a line
	sequential file.

   NOTE:
   =====
		
	For more details on how to call the File Handler please refer to the 
	File Handling Programmer's Guide in Chapter 7.
