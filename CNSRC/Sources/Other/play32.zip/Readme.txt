========================================================================
                          M I C R O F O C U S

                          N E T E X P R E S S
========================================================================
                          PROJECT Play32.zip
                          ==================

DATE CREATED: December, 2004
=============

The Play32.zip file contain the following two folders:

    PlaySound
    sndPlaySound

I found, when I opened the original Play32.zip file an example based 
upon the "sndPlaySound" API. This is not the recommended API for 
playing sounds under 32bit Windows. The "PlaySound" API is what should 
be used. The folders contain the corresponding API examples.

========================================================================
Micro Focus and Net Express are registered trademarks of Micro Focus
International, Inc.
========================================================================
Copyright (C) 1996-2004 Micro Focus, Inc.
