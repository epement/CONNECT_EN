      $ set Ans85 Mf'10' NoOsvs NoVsc2 NoQual NoAlter DefaultByte'00'
       special-names.
           call-convention 66 is cc66.
       working-storage section.
       77  APIReturn       pic xxxx    comp-5.
       77  fdwSound        pic xxxx    comp-5.
       77  hMod            pic xxxx    comp-5      value h'00'.
       77  szSound         pic x(11)               value z'chimes.wav'.
       77  winmmPtr                    procedure-pointer.
       78  programName                             value 'PlaySound'.
       78  SND-ASYNC                               value  1.
       78  SND-LOOP                                value  8.
       78  SND-MEMORY                              value  4.
       78  SND-NODEFAULT                           value  2.
       78  SND-NOSTOP                              value 16.
       78  SND-SYNC                                value  0.
       procedure division.
           display programName ': Starting.'
           set winmmPtr to entry 'winmm'
           if winmmPtr = NULL
             display programName
                 ': Unable to load winmm.dll, ending with error.'
             stop run
           end-if
           move SND-SYNC to fdwSound
           call cc66 'PlaySoundA' using
               by reference szSound
               by value     hMod
               by value     fdwSound
               returning    APIReturn
           end-call
           if APIReturn = ZERO
             display programName
                 ': PlaySound failed, ending with error.'
             stop run
           end-if
           display programName ': Ending.'
           exit program
           stop run.
