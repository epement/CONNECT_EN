      *----------------------------------------------------------------*
      *                          GETDISK                               *
      *                                                                *
      *   This sample program demonstrates two Windows API calls that  *
      *   can be used within a COBOL program in order to return infor- *
      *   mation pertaining to a specified disk drive.                 *
      *----------------------------------------------------------------*
       id division.
       program-id.  getdisk.
       environment division.
       special-names.
          call-convention 74 is winapi.
       data division.
       working-storage section.
       01  lpRootPathName           pic x(255)       value z"C:\".
       01  lpVolumeNameBuffer       pic x(255)       value spaces.
       01  lpVolumeSerialNumber     pic 9(9)  comp-5 value zeroes.
       01  lpMaximumComponentLength pic 9(9)  comp-5 value zeroes.
       01  lpFileSystemFlags        pic 9(9)  comp-5 value zeroes.
       01  lpFileSystemNameBuffer   pic x(255)       value spaces.

       01  lpDirectoryName          pic x(255)       value z"C:\".
       01  lpFreeBytesAvailable     pic 9(18) comp-5 value zeroes.
       01  lpTotalNumberofBytes     pic 9(18) comp-5 value zeroes.
       01  lpTotalNumberofFreeBytes pic 9(18) comp-5 value zeroes.
       01  ret-code                 pic s9(9) comp-5 value zeroes.
       procedure division.
       000-begin.

      ***  This call will get the volume information for the disk
      ***  specified in lpRootPathName. In this case "C:\".

           call winapi "GetVolumeInformationA"
              using by reference lpRootPathName
                    by reference lpVolumeNameBuffer
                    by value     length of lpVolumeNameBuffer
                    by reference lpVolumeSerialNumber
                    by reference lpMaximumComponentLength
                    by reference lpFileSystemFlags
                    by reference lpFileSystemNameBuffer
                    by value     length of lpFileSystemNameBuffer
              returning ret-code
           end-call

           if ret-code <> zeroes
              display "Volume Name          = " lpVolumeNameBuffer
              display "Volume Serial Number = " lpVolumeSerialNumber
              display "System Flags         = " lpFileSystemFlags
              display "File System Name     = " lpFileSystemNameBuffer
           else
              display "Error on GetVolumeInformation = " ret-code
           end-if

      ***  The following call gets the total and free disk space infor-
      ***  mation for the drive and directory specified by
      ***  lpDirectoryName in this case "C:\".

           call winapi "GetDiskFreeSpaceExA"
              using by reference lpDirectoryName
                    by reference lpFreeBytesAvailable
                    by reference lpTotalNumberofBytes
                    by reference lpTotalNumberofFreeBytes
              returning ret-code
           end-call

           if ret-code <> zeroes
              display "Free bytes available    = " lpFreeBytesAvailable
              display "Total Number of Bytes   = " lpTotalNumberofBytes
              display "Total Number Free Bytes = "
                 lpTotalNumberofFreeBytes
           else
              display "Error on GetDiskFreeSpaceEx = " ret-code
           end-if

           stop run.


