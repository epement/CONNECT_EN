   =========================================================================
                              M E R A N T

                          N E T E X P R E S S   
   =========================================================================
                              PROJECT XXXXXXX
                              ===============

   DATE CREATED:	11/15/2000
   =============

   BUILD W/RELEASE:  Net Express v3.1 with current fixpacks as of 02/17/2001
   ================

   TABLE OF CONTENTS
   =================
       INTRODUCTION
       SOURCE FILES
       REQUIREMENTS
       OPERATION


   INTRODUCTION
   ============

	Find Free Disk Space on a Drive using Windows API calls

   SOURCE FILES:
   =============

	Program Files	Description
	=============	=============================================

	diskinfo.cbl	Main program for sample

	Copy Files:
	============

	miniwin.cpy
	winerror.cpy
	wintypes.cpy



   REQUIREMENTS:
   =============
	*** NA

   OPERATION:
   ==========

	Open project and rebuild application


   NOTE:
   =====


   =========================================================================
   Micro Focus is a registered trademark, and MERANT and Net Express are
   trademarks of MERANT International Limited.
   =========================================================================
   Copyright (C) 1996-2000 MERANT International Limited