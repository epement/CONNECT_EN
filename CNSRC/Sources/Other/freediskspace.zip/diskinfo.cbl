      $set ans85 mf defaultbyte"00" case
       copy "winerror.cpy".
       identification division.
       program-id. diskinfo.
       special-names.
           call-convention 66 is WINAPI.

       data division.
       working-storage section.
       copy "miniwin.cpy".
       copy "wintypes.cpy".

       01  Buffer            pic x(1024).
       01  BufferLen         DWORD.
       01  Okay              BOOL.
       01  wx-sub1             pic s9(9)   comp-5.

       01  SectorsPerCluster           DWORD.
       01  BytesPerSector              DWORD.
       01  NumberOfFreeClusters        DWORD.
       01  TotalNumberOfClusters       DWORD.
       01  TotalBytes                  DWORD.

       01  FreeBytesAvailableToCaller  ULARGE-INTEGER.
       01  TotalNumberOfBytes          ULARGE-INTEGER.
       01  TotalNumberOfFreeBytes      ULARGE-INTEGER.

       78  GetDiskFreeSpaceEx          value "GetDiskFreeSpaceExA".
       78  GetDiskFreeSpace            value "GetDiskFreeSpaceA".

       01  good-ptr                    procedure-pointer.
       01  bad-ptr                     procedure-pointer.

       01  win95-OSR2flag              pic x       value "N".
           88  win95-osr2-or-above     value "N".
           88  win95-ga                value "Y".

       procedure division.
           call "cob32api"
           display erase
      *
      * Get the Computer Name
      *
           move 1024 to BufferLen
           call WINAPI GetComputerName using
                by reference Buffer,
                by reference BufferLen
                returning Okay
           end-call

           if Okay equals isTrue
               display "Computer name : " Buffer(1:BufferLen)
           else
              display "GetComputeName Failed..."
           end-if

           set bad-ptr  to entry "MERANTDoesNotExist"
           set good-ptr to entry GetDiskFreeSpaceEx
           if bad-ptr = good-ptr      *> We are running on Win95 GA
               set win95-ga            to true
           else
               set win95-osr2-or-above to true
           end-if


      ***** Use this on GA Win95

           display " "
           display "GetDiskFreeSpaceA"
           display "-----------------"

           call winapi GetDiskFreeSpace using
                   by reference z"c:\"
                   by reference SectorsPerCluster
                   by reference BytesPerSector
                   by reference NumberOfFreeClusters
                   by reference TotalNumberOfClusters
                returning Okay
           end-call

           if Okay equals isTrue
               display "SectorsPerCluster     " SectorsPerCluster
               display "BytesPerSector        " BytesPerSector
               display "NumberOfFreeClusters  " NumberOfFreeClusters
               display "TotalNumberOfClusters " TotalNumberOfClusters
               compute TotalBytes = SectorsPerCluster
                                  * BytesPerSector
                                  * NumberOfFreeClusters
               end-compute
               display " "
               display "Total Bytes Free      " TotalBytes
           else
               display "GetDiskFreeSpace Failed..."
           end-if

      ***** Use this on Win95 OSR2 and above

           if win95-osr2-or-above
               display " "
               display "GetDiskFreeSpaceEx"
               display "------------------"
               call winapi GetDiskFreeSpaceEx using
                       by reference z"c:\"
                       by reference FreeBytesAvailableToCaller
                       by reference TotalNumberOfBytes
                       by reference TotalNumberOfFreeBytes
                    returning Okay
               end-call

               if Okay equals isTrue
                   display "FreeBytesAvailableToCaller   "
                            FreeBytesAvailableToCaller
                   display "TotalNumberOfBytes           "
                            TotalNumberOfBytes
                   display "TotalNumberOfFreeBytes       "
                            TotalNumberOfFreeBytes
               else
                   display "GetDiskFreeSpace Failed..."
               end-if
           end-if

           stop run
           .
