       78  32BIT                                VALUE 1.
      $IF 32BIT DEFINED
       78 SZ                                  VALUE 9.
      $ELSE
       78 SZ                                  VALUE 4.
      $END
       78 isTRUE     value 1.
       78 isALSE    value 0.
       01 int      is typedef pic s9(SZ) comp-5.
       01 uint     is typedef pic 9(SZ) comp-5.
       01 short    is typedef pic s9(4) comp-5.
       01 ushort   is typedef pic 9(4) comp-5.
       01 long     is typedef pic s9(9) comp-5.
       01 ulong    is typedef pic 9(9) comp-5.
       01 ULARGE-INTEGER is typedef pic x(8) comp-5.
       01 WNDPROC  is typedef procedure-pointer.
       01 DLGPROC  is typedef procedure-pointer.
       01 HRGN     is typedef int.
       01 HWND     is typedef int.
       01 HANDLE   is typedef int.
       01 HINSTANCE is typedef int.
       01 HICON    is typedef int.
       01 HCURSOR  is typedef int.
       01 HDC      is typedef int.
       01 LPARAM   is typedef long.
       01 WPARAM   is typedef int.
       01 LRESULT  is typedef long.
       01 HBRUSH   is typedef int.
       01 HPEN     is typedef int.
       01 HMENU    is typedef int.
       01 BOOL     is typedef int.
       01 BYTE     is typedef pic x.
       01 COLORREF is typedef.
           03 red      pic x comp-5.
           03 green    pic x comp-5.
           03 blue     pic x comp-5.
           03 leadByte pic x comp-5.
       01 DWORD    is typedef ulong.
       01 HGDIOBJ  is typedef int.
       01 POINT    is typedef.
           03 px INT.
           03 py INT.
       01 RECT     is typedef.
           03 rleft   int.
           03 rtop    int.
           03 rright  int.
           03 rbottom int.
       01 PAINTSTRUCT is typedef.
           03 phdc         HDC.
           03 pfErase      BOOL.
           03 rcPaint      RECT.
           03 fRestore     BOOL.
           03 fIncUpdate   BOOL.
           03 rgbReserve   pic x(32).

       01 MSG      is typedef.
           03 msgWin        HWND.
           03 msgmessage    UINT.
           03 msgwordParam  WPARAM.
           03 msglongParam  LPARAM.
           03 msgtime       DWORD.
           03 msgpt         POINT.

       

       78 VER-PLATFORM-WIN32s value 0.
       78 VER-PLATFORM-WIN32-WINDOWS value 1.
       78 VER-PLATFORM-WIN32-NT value 2.

       01 OSVERSIONINFO is typedef.
           03 dwOSVersionInfoSize DWORD.
           03 dwMajorVersion DWORD.
           03 dwMinorVersion DWORD.
           03 dwBuildNumberFull.
               05 dwBuildNumber    ushort.
               05 dwMajorAndMinor  ushort.
           03 dwPlatformId   DWORD.
      $IF UNICODE DEFINED
           03 szCSDVersion   pic x(256).
           78 OSVERSIZE      value 276.
      $ELSE
           03 szCSDVersion   pic x(128).
           78 OSVERSIZE      value 148.
      $END
    
