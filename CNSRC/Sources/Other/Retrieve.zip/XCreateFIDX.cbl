123456$ set Ans85 Mf"10" NoOsvs NoVsc2 NoQual DefaultByte"00"
           select indexedFile  assign 'FLIndex.dat'
                               organization indexed
                               record key iFRKey = iFRColor iFRTone
                               alternate key iFRColor with duplicates
                               alternate key iFRTone with duplicates
                               access dynamic
                               file status fileStatus.
       fd  indexedFile.
       1   iFRecord.
       2   iFRColor pic x(10).
       2   iFRData pic x(10).
       2   iFRTone pic x(10).
       working-storage section.
       1   fileStatus.
       2   fileStatus1         pic x.
       2   runTimeError        pic x comp-x.
       1   wsColorValues.
       2   filler              pic x(10)   value 'Black'.
       2   filler              pic x(10)   value 'Blue'.
       2   filler              pic x(10)   value 'Red'.
       2   filler              pic x(10)   value 'White'.
       2   filler              pic x(10)   value 'Yellow'.
       1   wsColor             redefines wsColorValues
                               occurs 5 times indexed by wsCX
                               pic x(10).
       1   wsToneValues.
       2   filler              pic x(10)   value 'Light'.
       2   filler              pic x(10)   value 'Medium'.
       2   filler              pic x(10)   value 'Dark'.
       1   wsTone              redefines wsToneValues
                               occurs 3 times indexed by wsTX
                               pic x(10).
       77  recordCount         pic x comp-x.
       78  programName                     value 'CreateIdx'.
       procedure division.
           display programName ': Starting.'
           set wsCX wsTX to 1
           move all 'ABC' to iFRData
           open output indexedFile
           perform with test after
               varying wsCX from 1 by 1
               until (fileStatus <> '00' and <> '02') or wsCX = 5
             perform with test after varying wsTX from 1 by 1
               until (fileStatus <> '00' and <> '02') or wsTX = 3
               move wsColor(wsCX) to iFRColor
               move wsTone(wsTX) to iFRTone
               write ifRecord
               add 1 to recordCount
             end-perform
           end-perform
           if fileStatus1 = '9'
             display programName ': Run-time error=' runTimeError '.'
           else
             if fileStatus <> '02'
               display programName ': File Status=' fileStatus '.'
             end-if
           end-if
           close indexedFile
           display programName ': Record count=' recordCount '.'
           move ZERO to recordCount
           open i-o indexedFile
           move 'Black' to iFRColor
           move 'Dark' to iFRTone
           read indexedFile key is iFRColor
           perform until iFRTone = 'Dark'
             read indexedFile next record
           end-perform
           delete indexedFile record
           add 1 to recordCount
           move 'White' to iFRColor
           move 'Medium' to iFRTone
           read indexedFile key is iFRColor
           perform until iFRTone = 'Medium'
             read indexedFile next record
           end-perform
           delete indexedFile record
           add 1 to recordCount
           display programName ': Deleted ' recordCount ' records.'
           display programName ': Ending.'
           close indexedFile
           stop run.
