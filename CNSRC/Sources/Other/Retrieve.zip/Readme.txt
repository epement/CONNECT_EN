0        1         2         3         4         5         6
123456789012345678901234567890123456789012345678901234567890
===========================================================
                    M I C R O F O C U S 

                    N E T E X P R E S S
===========================================================
                       PROJECT Retrieve
                       ================

DATE CREATED: June, 2002
========================

BUILD WITH RELEASE: NetExpress 3.1, SP1
=======================================

TABLE OF CONTENTS
=================
INTRODUCTION
SOURCE FILES
REQUIREMENTS
OPERATION

INTRODUCTION
============
This project illustrates how to use Byte-stream File 
Routines to access and traverse an indexed file and 
summarize the records in the file by record code.

SOURCE FILES:
=============
Program Files	Description
=============	============================================
XCreateFIDX.cbl This program creates an indexed file 
                (FLIndex.dat/.idx) containing thirteen 
                records. You can edit this file with the 
                Data File Editor.
GetDeletes.cbl  This program handles the command line, 
                verifies that the file to be processed 
                exists, handles error conditions and 
                reports the record code summary. It calls 
                FileHDR.cbl to process the indexed file.
FileHDR.cbl     This program uses Byte-stream File Routines 
                to read the indexed file header and then 
                read through the file summarizing the 
                records in the file by record code.
Copy Files:
============
StandardFileHeader.cpy This copy book defines the structure 
                of the Standard File Header record that is 
                the first record of any indexed file. It 
                also documents the potential values for 
                each of the fields in the header.

REQUIREMENTS:
=============
NetExpress 3.1 with Service Pack 1 was used to create this 
example.

OPERATION:
==========
The programs have all been compiled and tested. Animate the 
GetDeletes.cbl program to determine exactly how the file 
processing is accomplished.

NOTE:
=====
Documentation on Byte-stream File Routines can be found in 
NetExpress Help by clicking on the Index tab and typing in 
Byte-stream Routine, selecting the article with the same 
name in window 2 and clicking the Display button.

Documentation on Indexed File Formats and Structures can be 
found in NetExpress Help by clicking on the Contents tab 
and opening these books:
    Reference
        File Handling
            File Structures
                Files with Headers

============================================================
Micro Focus and Net Express are registered trademarks, of 
Micro Focus, Inc.
============================================================
Copyright (C) 1996-2002 Micro Focus, Inc.

0        1         2         3         4         5         6
123456789012345678901234567890123456789012345678901234567890
