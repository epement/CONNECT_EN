      $ set Ans85 Mf"10" NoOsvs NoVsc2 NoQual DefaultByte"00"
       working-storage section.
       1   ExtendedFileStatus      pic xxxx    comp-x.
       1   ReturnedFileStatus      redefines ExtendedFileStatus.
       2   filler                  pic xx.
       2   StandardFileStatus.
       3   fileStatus1             pic x.
       3   runTimeError            pic x       comp-x.
       1   fileDetails.
       2   fileSize                pic x(8)    comp-x.
       2   fileDate.
       3   fileDay                 pic x       comp-x.
       3   fileMonth               pic x       comp-x.
       3   fileYear                pic xx      comp-x.
       2   fileTime.
       3   fileHour                pic x       comp-x.
       3   fileMinute              pic x       comp-x.
       3   fileSecond              pic x       comp-x.
       3   fileHundreth            pic x       comp-x.
       1   RecordCodeCounts.
       2   SystemRecord1Count      pic xx      comp-x.
       2   DeletedDataRecordCount  pic xx      comp-x.
       2   SystemRecord3Count      pic xx      comp-x.
       2   DataRecordCount         pic xx      comp-x.
       2   ReducedDataRecordCount  pic xx      comp-x.
       2   PointerRecordCount      pic xx      comp-x.
       2   ObjectDataRecordCount   pic xx      comp-x.
       2   ObjectReducedDataCount  pic xx      comp-x.
       2   InvalidRecordCodeCount  pic xx      comp-x.
       77  dataPortion             pic x(300).
       77  inputFileName           pic x(300).
       77  legend                  pic xxxxxx  value SPACES.
       77  stringPointer           pic xx      comp-x.
       78  programName                         value 'GetDeletes'.
       procedure division.
           display programName ': Starting.' end-display
           display programName
               ': Retrieve deleted index file records.'
           end-display
           accept inputFileName from COMMAND-LINE
           if inputFileName = SPACES
             display programName ': Usage: ' programName
                 ' [drive:\[path\]]filename<Enter>'
             end-display
             display programName ': Input File name missing.'
             end-display
             display programName ': Ending.' end-display
             stop run
           else
             move 1 to stringPointer
             string inputFileName delimited by '.'
                 into dataPortion
                 with pointer stringPointer
             end-string
             if stringPointer < length of inputFileName
               move SPACES to inputFileName(stringPointer:)
             end-if
             move 1 to stringPointer
             string inputFileName delimited by SPACE
                    '.DAT'        delimited by size
                 into dataPortion
                 with pointer stringPointer
             end-string
             call "CBL_CHECK_FILE_EXIST"
                 using by reference dataPortion
                       by reference fileDetails
             end-call
             if RETURN-CODE <> 0
               display programName ': Data File '
                   dataPortion(1:stringPointer - 1)
                   ' cannot be found.'
               end-display
               display programName ': Usage: ' programName
                   ' [drive:\[path\]]filename<Enter>'
               end-display
               display programName ': Ending.' end-display
               stop run
             end-if
           end-if
           call 'Filehdr' using by reference dataPortion
                                by reference legend
                                by reference RecordCodeCounts
           end-call
           if RETURN-CODE <> 0
             evaluate RETURN-CODE
             when 1 display programName
                    ': File does not begin with System header record.'
                    end-display
             when 2 display programName
                    ': File organization, format and mode incorrect.'
                    end-display
             when 3 display programName
                    ': File contains invalid record code.'
                    end-display
             when other
               move RETURN-CODE to ExtendedFileStatus
               if fileStatus1 = '9'
                 display programName
                 ': Byte Stream I-O has failed with Run-time error 9/'
                 runTimeError ' ' legend '.'
                 end-display
               else
                 display programName
                 ': Byte Stream I-O has failed with File Status = '
                 StandardFileStatus ' ' legend '.'
                 end-display
               end-if
             end-evaluate
           end-if
           if RETURN-CODE <> 0
             display programName ': Ending with error.' end-display
           else
             display programName ': System Record code 1   - '
             SystemRecord1Count       '.'      end-display
             display programName ': Deleted Data records   - '
             DeletedDataRecordCount   '.'      end-display
             display programName ': System Record code 3   - '
             SystemRecord3Count       '.'      end-display
             display programName ': Data Records           - '
             DataRecordCount          '.'      end-display
             display programName ': Reduced Data Records   - '
             ReducedDataRecordCount   '.'      end-display
             display programName ': Pointer Records        - '
             PointerRecordCount       '.'      end-display
             display programName ': Object Data Records    - '
             ObjectDataRecordCount    '.'      end-display
             display programName ': Object Reduced Records - '
             ObjectReducedDataCount   '.'      end-display
             display programName ': Invalid Record         - '
             InvalidRecordCodeCount   '.'      end-display
             display programName ': Ending.'   end-display
           stop run.
