      $ set Ans85 Mf"10"   Osvs NoVsc2 NoQual NoAlter DefaultByte"00"
      $ set CharSet"EBCDIC"
           select outputFile assign 'OSVSAAOF.DAT'
                             organization sequential.
       fd  outputFile.
       1   oFRecord.
           2   FILLER                 pic x. *> Printer Control char
           2   oFData                 pic x(132).
           2   oFLineNumber redefines oFData.
               3   oFDetailLineNumber pic 99.
               3   filler             pic x(130).
       working-storage section.
       1   pageLineCount      pic x    comp-x.
      * Note: "pageLineCount" will need to be adjusted in the Main
      *       Frame program as I can only get 57 lines per page using
      *       the "Courier New" font at "9 points." I think IBM Main
      *       Frame printers could put 66 lines per page.
       1   detailLineCount    pic x    comp-x.
      * Note: This exists only to keep track of the number of detail
      *       lines I'm printing.
       procedure division.
           open output outputFile
           perform printPageHeader
           perform printColumnHeading
           perform printDetailLine with test after
               varying detailLineCount from 1 by 1
               until detailLineCount = 23
           perform printPageHeader
           perform printColumnHeading
           perform printDetailLine with test after
               varying detailLineCount from 1 by 1
               until detailLineCount = 57
           perform printPageHeader
           perform printColumnHeading
           perform printDetailLine with test after
               varying detailLineCount from 1 by 1
               until detailLineCount = 42
           close outputFile
           stop run.
       printPageHeader.
           move all 'Page Heading Line 1 ' to oFData
           write oFRecord after advancing PAGE
           move all 'Page Heading Line 2 ' to oFData
           write oFRecord after advancing 1 line
           move 2 to pageLineCount.
       printColumnHeading.
           move all 'Column Heading Line 1 ' to oFData
           write oFRecord after advancing 2 lines
           move all 'Column Heading Line 2 ' to oFData
           write oFRecord after advancing 1 line
           move all 'Column Heading Line 3 ' to oFData
           write oFRecord after advancing 1 line
           add 4 to pageLineCount.
       printDetailLine.
           if pageLineCount = 6
             move all '   Detail Print Line' to oFData
             move detailLineCount to oFDetailLineNumber
             write oFRecord after advancing 2 lines
             move 7 to pageLineCount
           else
             move all '   Detail Print Line' to oFData
             move detailLineCount to oFDetailLineNumber
             write oFRecord after advancing 1 line
           end-if
           add 1 to pageLineCount
           if pageLineCount = 57
             perform printPageHeader
             perform printColumnHeading
           end-if.
