============================================================
                    M I C R O F O C U S 

                    N E T E X P R E S S
============================================================
                   PROJECT MAINFRAMEPRINT
                   ======================

DATE CREATED: March, 2004
=============

BUILD WITH RELEASE: NetExpress 3.1
==================================

TABLE OF CONTENTS
=================
INTRODUCTION
FILES
REQUIREMENTS
OPERATION

INTRODUCTION
============
This example illustrates the MAINFRAMEPRINT File Handler 
Configuration option. This option creates a Mainframe style 
report file on the PC when using Before/After Advancing 
syntax. Each record begins with a Mainframe Printer Control 
Character in the first position. The report record 
definition must reserve the initial record position for the 
printer control charater. The remainder of the record, 
beginning with position 2, would contain the data that is 
to be printed.

FILES:          Description
======          ===========

Configuration
=============
extfh.cfg       A File Handler Configuration file specifying
                the MAINFRAMEPRINT=ON configuration option. 
                This text file consists of two lines: 
                [OSVSAAOF.DAT]
                MAINFRAMEPRINT=ON
                The first line identifies the data file to 
                which the option is to be applied and the 
                second line specifies the option as "ON". 
                The data file should be a fixed length, 
                record sequential, output file.

Program Files
=============
Osvsaa.cbl      A COBOL application program that uses After 
                Advancing syntax to create a report file 
                named "OSVSAAOF.DAT". The output file is a 
                fixed length, record sequential file. The 
                record size is 133 bytes. The report content 
                is limited to record positions 2 though 132. 
                This program is compiled with the 
                CharSet"EBCDIC" compiler directive. The 
                report file is intended for printing on a 
                mainframe computer.

Opcw32AP.cbl    A COBOL application program that prints a 
                MAINFRAMEPRINT report file on a PC printer.
                This is an  ASCII program. The CODE-SET 
                option and an alphabet definition are used 
                to translate the EBCDIC data file to ASCII 
                as each record is read into the program.

REQUIREMENTS:
=============
This example was developed and tested using Net Express 3.1, 
SP1 and all subsequent FixPacks. It should also rebuild and 
function using Net Express 4.0 with all FixPacks applied as 
of March 29, 2004.

OPERATION:
==========
You will need to modify these constants:
    78 workPrinterName         value '\\PRODSUP2\HP340_5s'.
    78 workPrinterNameLength   value 19.
in the Opcw32AP.cbl program to a printer name and length 
that will match what is available at your location.

============================================================
Micro Focus and Net Express are registered trademarks, of 
Micro Focus, International, Inc.
============================================================
Copyright (C) 1996-2004 Micro Focus, Inc.

