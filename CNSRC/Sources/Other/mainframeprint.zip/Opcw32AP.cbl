123456$ set SourceFormat"Free"
$ set Ans85 Mf"10" NoOsvs NoVsc2 NoQual NoAlter DefaultByte"00"
* Opcw32AP,cbl - This example program is intended to illustrate how a report file created with the
*              - MAINFRAMEPRINT File Handler Configuration option can be printed using PC_PRINTER...
*                call-by-name routines. The print routine names used in this program are :
*                    PC_PRINTER_SET_DEFAULT
*                    PC_PRINTER_OPEN
*                    PC_PRINTER_SET_FONT
*                    PC_PRINTER_WRITE
*                    PC_PRINTER_CLOSE
*                This program also makes use of the CBL_CHECK_FILE_EXISTS call-by-name routine
*                to determine if the file name provided from the command line actually exists.
special-names. alphabet ASCIITRAN is EBCDIC.
select inputFile assign inputFileName
                 organization sequential
                 access sequential
                 file status is FS.
* Note: The above is a fixed length record (133 bytes) sequential file which is being accessed
*       sequentially. This is the type of file produced when the "after positioning" report
*       file is diverted to disk rather than going directly to the printer.
* Note: "inputFileName" is not a ddname nor is it a file name. It is a dataname that will need
*       to be initialized with a proper PC filename before this logical file can be used.
* Note: A "file status" clause is specified. This is essential to determining if the file
*       processing is proceeding according to plan.
fd inputFile CODE-SET is ASCIITRAN.
1 iFRecord.
2 iFPCC             pic x.
2 iFData            pic x(132).
* Note: There are only two fields in the input record. The "print control character" (iFPCC)
*       and the data content of the record (iFData) which is the print line. The program uses
*       the print control character to position the paper and isn't concerned about the
*       print line since the program is only going to print this information.
working-storage section.
78 programName                   value 'OPCW32AP'.
78 selectPrinterDialog           value  1.
78 selectFontDialog              value  2.
78 portraitOrientation           value  4.
78 landscapeOrientation          value  8.
78 progressIndicator             value 16.
78 homePrinterName               value 'HP LaserJet 6P'.
78 homePrinterNameLength         value 14.
78 workPrinterName               value '\\can-mtlntsrv\hplj5mtl'.
78 workPrinterNameLength         value 23.
* Note: The above are "constants," another Micro Focus extension. They persist only during the
*       compilation of the program and are incorporated into the generated program wherever
*       referenced. With the exception of "programName" they are good candidates for a
*       copybook, if you can reach a consensus on how to name your constants.
1 FS.
2 FS1               pic x.
2 FS2               pic x.
2 RTE redefines FS2 pic x comp-x.
* Note: The above is a pretty conventional definition of the "file status" data structure.
*       This field is two Ascii bytes (display). When testing the field value use a nonnumeric
*       literal to evaluate the current setting. '00' is OK. Any value other than this
*       indicates, depending on the type of file being processed, that you have a problem or
*       need a processing alternative.
* Note: When the first byte of file status (FS1) is an Ascii nine ('9') then what has occurred
*       is a Run-time error. Use the redefinition (RTE) of the second byte of file status
*       (FS2) to determine the numeric value of the Run-time error. These errors are usually
*       displayed as "9/013" on the screen, for example, by the Run-time. You can capture this
*       same information in a logging file for the execution of the program.
1 fileDetails.
2 fileSize          pic x(8) comp-x.
2 fileDate.
3 fileDay           pic x    comp-x.
3 fileMonth         pic x    comp-x.
3 fileYear          pic xx   comp-x.
2 fileTime.
3 fileHour          pic x    comp-x.
3 fileMinute        pic x    comp-x.
3 fileSecond        pic x    comp-x.
3 fileHundreth      pic x    comp-x.
* Note: The structure above is needed by the CBL_CHECK_FILE_EXITS call-by-name routine. It is
*       populated only when the file is actually found.
1 setPrinterOption  pic xxxx comp-5 value 1. *> The Set Default Printer Option for Win 95/98.
* Note: The item above defines which Default printer set up option we want.
*       There are two (2) options avaiable.
*       1    Sets the default printer to the name you specify.
*       2    Browses for a default printer. (This option is only available on Windows NT.)
*       When option 1 is specified: the length of your printer name and the name of your
*       printer must be specified as below.
*       When option 2 is specified: the handle for the printer browser must be specified.
1 printerName.                       *> The printer we want to set as the default.
2 printerNameSize   pic xx   comp-5 value workPrinterNameLength. *> The length of the name.
2 thePrinterName    pic x(workPrinterNameLength) value workPrinterName.
* Note: The above items are used in the PC_PRINTER_SET_DEFAULT call-by-name routine to set up
*       a default printer for this program.
1 statusCode        pic xx   comp-5. *> The PC_PRINTER routines return code. Must be tested.
* Note: All the PC_PRINTER routines and the CBL_CHECK_FILE_EXIST routine use this item as a
*       return code that must be evaluated to ensure they have worked correctly.
1 printerHandle     pic xxxx comp-5. *> This printer handle is returned by PC_PRINTER_OPEN.
1 documentTitle.                     *> This Report Description will appear in the Spooler.
2 dTLength          pic xx   comp-5.
2 dTText            pic x(20)       value 'My Report'.
1 printerFlags      pic xxxx comp-5. *> These flags can be used to customize your use of the
* bit decimal description            *> PC_PRINTER_OPEN routine.
* The decimal values can be added to together into a composite setting. Note Exclusions!
*  0   0/1    Printer Dialog     - Permits selection of printer, paper, orientation, etc..
*  1   0/2    Font Dialog        - Permits selection of font, style, size etc..
*  2   0/4    Portrait           - Sets paper Orientation, 8 1/2" horizontal, 11" vertical.
*  3   0/8    Landscape          - Sets paper Orientation, 11" horizontal, 8 1/2" vertical.
*  4   0/16   Progress Indicator - Display MessageBox with a Cancel button. Hard to Animate.
* Bits 2 and 3 are mutally exclusive, it's either, but never both.
* Bit 0 is mutually exclusive of Bits 2 and 3, if you want the Dialog, you can't specify the
* orientation.
* Note: The above item is used to set up the printer by the PC_PRINTER_OPEN routine.
1 fontFamilyName.                    *> The name data structure.
2 fontNameSize      pic xx   comp-5. *> The length of the font name shown below.
2 fontCourierNew    pic x(11)       value 'Courier New'.
1 fontPointSize     pic xxxx comp-5. *> The font point size to be used.
1 fontStyle         pic xxxx comp-5. *> The font style to be used. Zero (0) is "Plain."
* The decimal values can be added to together into a composite setting.
* bit decimal description
*  0   0/1    Italic
*  1   0/2    Underline
*  2   0/4    Strikeout
*  3   0/8    Bold
* 4-7         Reserved
* Note: The above items are used to set up a default font by the PC_PRINTER_SET_FONT routine.
1 lineBuffer        pic x(132).      *> The buffer from which report lines are printed.
1 lineBufferSize    pic xxxx comp-5. *> The size of the above buffer.
* Note:
1 CRLF.                              *> A series of constants needed for line spacing.
2 oneSpace          pic xx          value x'0D0A'. *> Carriage
2 twoSpace          pic xx          value x'0D0A'. *> Returns and
2 threeSpace        pic xx          value x'0D0A'. *> Line Feeds
1 formFeed          pic x           value x'0C'.   *> Form feed
* Note:
1 advanceBuffer     pic x(6).        *> The buffer used for line spacing.
1 advanceBufferSize pic xxxx comp-5. *> The size of the above buffer, dynamic.
88 singleSpacing                    value 2.
88 doubleSpacing                    value 4.
88 tripleSpacing                    value 6.
88 suppressSpacing                  value 1.
88 newPage                          value 1.
78 singleSpace                      value ' '.
78 doubleSpace                      value '0'.
78 tripleSpace                      value '-'.
78 noSpace                          value '+'.
78 nextPage                         value '1'.
* Note: The above are used in the PC_PRINTER_WRITE routine calls to print the paper advancing
* and report lines.
procedure division.
* There isn't a lot of application programming here, but there is a lot of code devoted to
* monitoring the progress of input and output. This is essential to ensure that when something
* goes wrong, the problem can be recorded and then rectified.
accept inputFileName from COMMAND-LINE *> This acquires the input file name.
if inputFileName = SPACES              *> The file name must pass some simple validation.
  display programName ': Processes "After Positioning" Report file.'
  display programName ' Usage: ' programName ' filename<Enter>'
  display programName ': Input File name missing.'
  display programName ': Ending.'
  stop run
else                                   *> When a file name has been provided this
  call "CBL_CHECK_FILE_EXIST"          *> call-by-name routine can determine if it exists.
      using by reference inputFileName
               by reference fileDetails
      returning          statusCode
  if statusCode <> 0                   *> Non zero is bad, drive, path or file name not good.
    display programName ': Processes "After Positioning" Report file.'
    display programName ' Usage: ' programName ' filename<Enter>'
    display programName ': Input File name cannot be found.'
    display programName ': Ending.'
    stop run
  end-if
end-if
display programName ': Starting.'
open input inputFile                            *> This opens the input file.
if FS = '00'                                    *> This makes sure it worked.
  move landscapeOrientation to printerFlags     *> These statements accomplish the
  move length of lineBuffer to lineBufferSize   *> initialization necessary to the printing
  move length of fontCourierNew to fontNameSize *> of the report file.
* move 9 to fontPointSize *> At Home.
  move 8 to fontPointSize *> At Work.
  move 0 to fontStyle
  call 'PC_PRINTER_SET_DEFAULT'          *> This sets the default printer.
      using by value     setPrinterOption
            by reference printerName
      returning          statusCode
  if statusCode = 0                      *> This confirms that the printer has been set.
    call 'PC_PRINTER_OPEN'               *> This opens the printer.
        using by reference printerHandle
              by reference documentTitle
              by value     printerFlags
              by value     0 size 4      *> This is a default Window Handle, that would center
        returning          statusCode    *> the Dialog, that we are not using, over the Desktop.
    if statusCode = 0                    *> This confirms that the printer has been opened.
      call 'PC_PRINTER_SET_FONT'         *> This set ups the font that we want to use.
          using by reference printerHandle
                by reference fontFamilyName
                by value     fontPointSize
                by value     fontStyle
          returning          statusCode
      if statusCode = 0                  *> This confirms that the font has been set up.
        read inputFile                   *> This reads the first record from the report file.
        if FS = '00'                     *> This confirms that the read was successful.
          perform with test after until FS <> '00' *> This perform prints and reads until an
                                                   *> error occurs or there is no more input.
            move iFData to lineBuffer        *> Fill the line buffer with record data.
            move CRLF to advanceBuffer       *> Fill the advancing buffer.
            evaluate iFPCC                   *> Evaluate the print control character.
            when singleSpace                 *> Space, single space.
              set singleSpacing to TRUE
            when doubleSpace                 *> Zero, double space.
              set doubleSpacing to TRUE
            when tripleSpace                 *> Hyphen, triple space.
              set tripleSpacing to TRUE
            when noSpace                     *> Plus, suppress spacing.
              set suppressSpacing to TRUE
            when nextPage                    *> One, Skip to Channel 1 (new page).
              move formFeed to advanceBuffer *> Fill the advancing buffer.
              set newPage to TRUE
            when other                       *> Uh Oh! Invalid Print Control Character!
              display programName ': Invalid Print Control Character detected!'
              move '10' to FS
              exit perform
            end-evaluate
            call 'PC_PRINTER_WRITE'          *> Print the advancing specification.
                using by reference printerHandle
                      by reference advanceBuffer
                      by value     advanceBufferSize
                returning statusCode
            if statusCode <> 0               *> If printing failed, display message, and
              display programName ': Unable to print positioning.'
              move '10' to FS                *> end file processing with an EOF file status.
            else                             *> If printing OK,
              call 'PC_PRINTER_WRITE'        *> Print the report line.
                  using by reference printerHandle
                        by reference lineBuffer
                        by value     lineBufferSize
                  returning statusCode
              if statusCode <> 0             *> If printing failed, display message, and
                display programName ': Unable to print report line.'
                move '10' to FS              *> end file processing with an EOF file status.
              else                           *> If printing OK,
                read inputFile               *> Read the next report file record.
              end-if                         *> The condition on the perform will trap any
            end-if                           *> error or end of file.
          end-perform                        *> End of perform.
          if FS = '10' and statusCode = 0    *> Did it printing terminate properly?
            call 'PC_PRINTER_WRITE'          *> Print last page.
                using by reference printerHandle
                      by reference formFeed
                      by value     1 size 4
                returning statusCode
            if statusCode = 0                *> Confirm that last page printed.
              continue                       *> When everything is OK, we're out of here!
            else                             *> When print fails, output message, and
              display programName ': Unable to clear last page.'
            end-if                           *> out of here.
          else                               *> When perform doesn't end correctly
            perform checkFileStatus
            display programname ': Unable to read input file.'
          end-if
        else
          perform checkFileStatus
          display programname ': Unable to read input file.'
        end-if
      else
        display programName ': Unable to set Font.'
      end-if
      close inputFile
      call 'PC_PRINTER_CLOSE'
          using by reference printerHandle
      if statusCode <> 0
        display programName ': Unable to close printer.'
      end-if
    else
      display programName ': Unable to open printer.'
    end-if
  else
    display programName ': Unable to set deafult printer.'
  end-if
else
  perform checkFileStatus
  display programname ': Unable to open input file.'
end-if
display programName ': Ending.'
stop run.
checkFileStatus.
* This paragraph performs a rudimentary check of file status and displays the result on the
* screen.
if FS <> '00'
  if FS1 = '9'
    display programName ': Run-time error 9/' RTE
  else
    display programName ': File status - ' FS
  end-if
end-if.
