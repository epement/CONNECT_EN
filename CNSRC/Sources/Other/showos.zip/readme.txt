   =========================================================================
                              Micro Focus

                          N E T E X P R E S S   
   =========================================================================
                              PROJECT ShowOS
                              ===============

   DATE CREATED:
   =============

   BUILD W/RELEASE:  Net Express v3.1
   ================

   TABLE OF CONTENTS
   =================
       INTRODUCTION
       SOURCE FILES
       OPERATION


   INTRODUCTION
   ============
	
	Demonstrate how to use the GetVersion API.  This version will work on all current version of Windows OS 

   SOURCE FILES:
   =============

	Program Files	Description
	=============	=============================================

	showos.cbl


   OPERATION:
   ==========

	Rebuild project and run or animate.

   NOTE:
   =====


