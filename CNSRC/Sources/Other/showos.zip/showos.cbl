      $set ans85 mf defaultbyte"00" case remove(beep) remove(escape)
       identification division.
       program-id. "ShowOS".
       special-names.
           call-convention 74 is WinAPI.

       data division.
       working-storage section.

       78 SZ                                  VALUE 9.
       78 isTRUE     value 1.
       78 isFALSE    value 0.
       78 VER-PLATFORM-WIN32s                value           0.
       78 VER-PLATFORM-WIN32-WINDOWS         value           1.
       78 VER-PLATFORM-WIN32-NT              value           2.
       78 MAJOR-OSVERSION-NT351              value           3.
       78 MAJOR-OSVERSION-9598MENT4          value           4.
       78 MAJOR-OSVERSION-2000WHISTLER       value           5.
       78 MINOR-OS-WIN95                     value           0.
       78 MINOR-OS-WIN98                     value          10.
       78 MINOR-OS-WINME                     value          90.
       78 MINOR-OS-WINNT351                  value          51.
       78 MINOR-OS-WINNT2000                 value           0.
       78 MINOR-OS-WINWHISTLER               value           1.
       78 CSDVERSION-WIN95                   value         "C".
       78 CSDVERSION-WIN98                   value         "A".


       01 int      is typedef pic s9(SZ) comp-5.
       01 uint     is typedef pic 9(SZ) comp-5.
       01 short    is typedef pic s9(4) comp-5.
       01 ushort   is typedef pic 9(4) comp-5.
       01 long     is typedef pic s9(9) comp-5.
       01 ulong    is typedef pic 9(9) comp-5.
       01 DWORD    is typedef pic 9(9) comp-5.
       01 BOOL     is typedef int.

       01 OSVERSIONINFO is typedef.
           03 dwOSVersionInfoSize DWORD.
           03 dwMajorVersion DWORD.
           03 dwMinorVersion DWORD.
           03 dwBuildNumberFull.
               05 dwBuildNumber    ushort.
               05 dwMajorAndMinor  ushort.
           03 dwPlatformId   DWORD.
      $IF UNICODE DEFINED
           03 szCSDVersion   pic x(256).
       78 OSVERSIZE      value 276.
       78 GetVersionEx value "GetVersionExW".
      $ELSE
           03 szCSDVersion   pic x(128).
       78 OSVERSIZE      value 148.
       78 GetVersionEx value "GetVersionExA".
      $END
    
       01 ws-myOSVer           OSVERSIONINFO.
       01 ws-myOSOk            BOOL.
       01 ws-myLastError       DWORD.

       linkage section.
       procedure division WinApi.

           call "cob32api"
           move OSVERSIZE to dwOSVersionInfoSize of ws-myOSVer
           call WinAPI GetVersionEx using
                by reference ws-myOSVer
                returning ws-myOSOk
           end-call

           if ws-myOSOK equals isTRUE

                display "Win32 Platform : " no advancing
                evaluate dwPlatformId of ws-myOSVer
                when VER-PLATFORM-WIN32s
                    display "Support win32s"
                    stop run
                when VER-PLATFORM-WIN32-WINDOWS
                    evaluate dwMajorVersion of ws-myOSVer
                    when MAJOR-OSVERSION-9598MENT4
                         evaluate dwMinorVersion of ws-myOSVer
                         when MINOR-OS-WIN95
                            display "Windows 95" no advancing
                            evaluate szCSDVersion of ws-myOSVer
                            when CSDVERSION-WIN95
                               display " OSR2"
                            when other
                               display " "
                            end-evaluate
                         when MINOR-OS-WIN98
                            display "Windows 98"
                            evaluate szCSDVersion of ws-myOSVer
                            when CSDVERSION-WIN98
                               display " Second Edition"
                            when other
                               display " "
                            end-evaluate
                         when MINOR-OS-WINME
                            display "Windows Millenium"
                         end-evaluate
                    end-evaluate
                when VER-PLATFORM-WIN32-NT
                    evaluate dwMajorVersion of ws-myOSVer
                    when MAJOR-OSVERSION-NT351
                         display "Windows NT 3.51"
                    when MAJOR-OSVERSION-9598MENT4
                         display "Windows NT 4.0"
                         display "Service pack level: " szCSDVersion
                    when MAJOR-OSVERSION-2000WHISTLER
                         evaluate dwMinorVersion of ws-myOSVer
                         when MINOR-OS-WINNT2000
                            display "Windows 2000"
                            display "Service pack level: " szCSDVersion
                         when MINOR-OS-WINWHISTLER
                            display "Windows Whistler"
                         end-evaluate
                    end-evaluate
                end-evaluate

                display "Win32 Version  : "
			dwMajorVersion of ws-myOSVer
                        "."
			dwMinorVersion of ws-myOSVer
                display "Win32 Build    : " dwBuildNumber of ws-myOSVer
          end-if

          stop run.
