   =========================================================================
                              Micro Focus

                          N E T E X P R E S S   
   =========================================================================
                            PROJECT GETVER
                            ================

   DATE CREATED:         September 20, 2001
   =============

   BUILD W/RELEASE:      3.1
   ================

   TABLE OF CONTENTS
   =================
        INTRODUCTION
        SOURCE FILES
        REQUIREMENTS
        OPERATION

   INTRODUCTION
   ============
        This program demonstrates how to use the Windows 32-bit API
        functions to get the Windows version information from a file.

   SOURCE FILES:
   =============

        Program Files   Description
	=============	=============================================
        GETVER.CBL      Program that calls the WINAPI functions.

        VERSION.LIB     Import library from the Windows SDK. This file is
                        linked into GETVER.EXE to resolve the references to
                        GetFileVersionInfoSize, GetFileVersionInfo, and
                        VerQueryValue. This is provided with the Windows SDK.
                        See requirements.

   REQUIREMENTS:
   =============
        This sample should run in all environments.

        In order to link this program you need to install the Microsoft
        Windows 32-bit SDK. This CD-ROM is supplied with Net Express.
        The installation should create a directory MSTOOLS\LIB directory.
        Modify the Build Settings for GETVER.EXE under Link/Advanced and
        change the location of VERSION.LIB to point to the directory
        containing this file on your system.

   OPERATION:
   ==========
        Rebuild this project to create the file GetVer.exe.
        This is a character mode program that will display the version
        information for the file \WINDOWS\WINSOCK.DLL. You can change this
        value to display version information for any file on you system.

   NOTE:
   =====
        The file VERSION.LIB is specified under Project/Build Settings/
        Link/Advanced in the Link with these LIB's field. It must be
        included in any program that makes a call to GetFileVersionInfoSize,
        GetFileVersionInfo, or VerQueryValue. This is provided with the Windows
        SDK.
   =========================================================================
   Micro Focus is a registered trademark, and Net Express is a trademark of
   Micro Focus.
   =========================================================================
   Copyright (C) 1996-2001 Micro Focus
