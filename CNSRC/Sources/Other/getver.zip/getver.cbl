       id division.
       program-id.     GET-VERSION.
       environment division.
       configuration section.
       special-names.
           call-convention 74 is winapi.
       data division.
       working-storage section.
       78 PROGRAM-NAME                    value "GETVER".
       01 info-to-get.
          05                pic x(15)     value "\StringFileInfo".
          05                pic x(10)     value "\040904E4\".
          05 info-string    pic x(20)     value spaces.

       01 file-name         pic x(30)
          value z"c:\winnt\system32\winsock.dll".
       01 version-info      pic x(1000)   value spaces.
       01 buffer-size       pic 9(9) comp-5.
       01 handle            pic 9(9) comp-5.
       01 ret-code          pic 9(9) comp-5.
       01 version-pointer   pointer.
       01 version-length    pic 9(4) comp-5.
       01 any-key           pic x.
       linkage section.
       01 returned-info     pic x(100).
       procedure division.
       000-begin.

           display "Starting " PROGRAM-NAME

           perform 100-get-structure-size
           perform 105-get-version-info
           perform 110-get-version-data
           display "Ending " PROGRAM-NAME
           stop run.

      *----------------------------------------------------------------*

       100-get-structure-size.

           call winapi "GetFileVersionInfoSizeA"
              using by reference file-name
                    by reference handle *> not used, set to zero
              returning buffer-size
           end-call

           if buffer-size = 0
              display "Error in call GetFileVersionInfoSize"
              accept any-key
              stop run
           end-if.

      *----------------------------------------------------------------*

       105-get-version-info.

           call winapi "GetFileVersionInfoA"
              using by reference file-name
                    by value handle *> not used, set to zero
                    by value buffer-size
                    by reference version-info
              returning ret-code
           end-call
           if ret-code = 0
              display "Error in call GetFileVersionInfo"
              accept any-key
              stop run
           end-if.

      *----------------------------------------------------------------*

       110-get-version-data.

           move z"CompanyName" to info-string
           perform 200-get-value
           move z"FileDescription" to info-string
           perform 200-get-value
           move z"FileVersion" to info-string
           perform 200-get-value
           move z"InternalName" to info-string
           perform 200-get-value
           move z"LegalCopyright" to info-string
           perform 200-get-value
           move z"OriginalFilename" to info-string
           perform 200-get-value
           move z"ProductName" to info-string
           perform 200-get-value
           move z"ProductVersion" to info-string
           perform 200-get-value.

      *----------------------------------------------------------------*

       200-get-value.

           call winapi "VerQueryValueA"
              using by reference version-info
                    by reference info-to-get
                    by reference version-pointer
                    by reference version-length
              returning ret-code
           end-call
           if ret-code = 0
              display "Error in call VerQueryValue"
              accept any-key
              stop run
           end-if

           display info-string with no advancing

           if version-length = 0
              display "No Value Found!"
           else
              set address of returned-info to version-pointer
              display returned-info(1:version-length)
           end-if.


