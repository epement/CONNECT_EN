      *----------------------------------------------------------------*
      *                        RECYCLEDEL                              *
      *                                                                *
      *   This sample program will demonstrate how to use the Windows  *
      *   SHFileOperation API in order to send a file to the Recycle   *
      *   Bin when it is deleted.                                      *
      *                                                                *
      *   This application will first call the subprogram "SelectFile" *
      *   which uses the Net Express Class Library in order to display *
      *   a Windows OpenFileName dialog box so that the user can select*
      *   the name of a file to delete.                                *
      *                                                                *
      *   The default filter used for the select file is *.tmp within  *
      *   the current directory. A number of temp files with this      *
      *   extension are provided in the project directory.             *
      *                                                                *
      *   Once a filename is selected and returned, this program will  *
      *   use the SHFileOperation API with the Delete function and the *
      *   FOF-ALLOWUNDO flag which causes the deleted file to be sent  *
      *   to the Windows Recycle Bin so that it can be restored at a   *
      *   later time.                                                  *
      *                                                                *
      *   After running this sample program, open up the Recycle Bin   *
      *   and the file that you deleted should be displayed.           *
      *----------------------------------------------------------------*
       id division.
       program-id.    recycledel.
       environment division.
       special-names.
          call-convention 74 is winapi.
       data division.
       working-storage section.
       78  FO-MOVE                            value h'0001'.
       78  FO-COPY                            value h'0002'.
       78  FO-DELETE                          value h'0003'.
       78  FO-RENAME                          value h'0004'.

       78  FOF-MULTIDESTFILES                 value h'0001'.
       78  FOF-CONFIRMMOUSE                   value h'0002'.
       78  FOF-SILENT                         value h'0004'. *> don't create progress/report
       78  FOF-RENAMEONCOLLISION              value h'0008'.
       78  FOF-NOCONFIRMATION                 value h'0010'. *> don't prompt the user.
       78  FOF-WANTMAPPINGHANDLE              value h'0020'. *> Fill inSHFILEOPSTRUCT.h NameMappings
                                                             *> Must be freed using SHFreeNameMappings
       78  FOF-ALLOWUNDO                      value h'0040'.
       78  FOF-FILESONLY                      value h'0080'. *> on *.*,do only files
       78  FOF-SIMPLEPROGRESS                 value h'0100'. *> means don't show names of files
       78  FOF-NOCONFIRMMKDIR                 value h'0200'. *> don't confirm making any needed dirs
       78  FOF-NOERRORUI                      value h'0400'. *> don't put up error UI
       78  FOF-NOCOPYSECURITYATTRIBS          value h'0800'. *> dont copy NT file Security Attributes

       01  SHFILEOPSTRUCT.
           05  shhwnd                 pic x(4) comp-5 value zeroes.
           05  wFunc                  pic x(4) comp-5 value zeroes.
           05  pFrom                  pointer.
           05  pTo                    pointer.
           05  fFlags                 pic x(4) comp-5 value zeroes.
           05  fAnyOperationsAborted  pic x(4) comp-5 value zeroes.
           05  hNameMappings          pic x(4) comp-5 value zeroes.
           05  lpszProgressTitle      pointer.

       01  FOF-FromName               pic x(256)      value spaces.
       01  FOF-ToName                 pic x(256)      value low-values.
       01  FOF-ProgressTitle          pic x(256)      value low-values.
       01  ret-code                   pic x(4) comp-5 value zeroes.
       procedure division.
       000-begin.

           call "SelectFile" using FOF-FromName
           if FOF-FromName = spaces
              display "No file name entered!" at 0505 with erase
              stop run
           end-if

           set pFrom to address of FOF-FromName
           set pTo to address of FOF-ToName
           set lpszProgressTitle to address of FOF-ProgressTitle

           move FO-DELETE to wFunc
           move FOF-ALLOWUNDO to fFlags

           call WINAPI "SHFileOperationA"
              using SHFILEOPSTRUCT
              returning ret-code
           end-call

           if ret-code = 0
              display "Delete Successful!" at 0505
           else
              display "Error on Delete = " at 0505
                      ret-code at 0523
           end-if
           stop run.
