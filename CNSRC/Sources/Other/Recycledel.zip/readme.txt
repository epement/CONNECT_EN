   =========================================================================
                              MICRO FOCUS

                          N E T E X P R E S S   
   =========================================================================
                         PROJECT RecycleDel
                         ==================

   DATE CREATED: May 2004
   =============

   BUILD W/RELEASE:  NetExpress 4.0
   ================

   TABLE OF CONTENTS
   =================
      INTRODUCTION
      SOURCE FILES
      REQUIREMENTS
      OPERATION

   INTRODUCTION
   ============

      This sample program will demonstrate how to use the Windows
      SHFileOperation API in order to send a file to the Recycle
      Bin when it is deleted.

      This application will first call the subprogram "SelectFile"
      which uses the Net Express Class Library in order to display
      a Windows OpenFileName dialog box so that the user can select
      the name of a file to delete.

      The default filter used for the select file is *.tmp within
      the current directory. A number of temp files with this
      extension are provided in the project directory.

      Once a filename is selected and returned, this program will
      use the SHFileOperation API with the Delete function and the
      FOF-ALLOWUNDO flag which causes the deleted file to be sent
      to the Windows Recycle Bin so that it can be restored at a
      later time.

      After running this sample program, open up the Recycle Bin
      and the file that you deleted should be displayed.

      For more detailed information on using the SHFileOperation API
      use the following link:

      http://msdn.microsoft.com/library/default.asp?url=/library/en-us/shellcc/
      platform/shell/reference/functions/shfileoperation.asp


   SOURCE FILES:
   =============

        Program Files     Description
        =============     =============================================

        recycledel.cbl    COBOL main program that calls the SHFileOperation API.

        selectfile.cbl    Subprogram which is called to let the user select
                          a filename to be deleted, from a Dialog Box.

        TEMP1.TMP         Temporary files that can be selected in this demo.
        TEMP2.TMP
        TEMP3.TMP


   REQUIREMENTS:
   =============
        Installation of the GUI class library source files option
        during NetExpress setup. Also requires that the Library SHELL32.LIB
        be added to the Link options for recycledel.exe.

   OPERATION:
   ==========
        Run this program to display a File Open dialog box, select
        a file, and the selected file name will be sent to the Recycle Bin.


