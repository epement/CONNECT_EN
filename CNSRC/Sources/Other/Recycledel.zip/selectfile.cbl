       id division.
       program-id. selectfile.
       environment division.
       class-control.
           EventManager is class "p2emgr"
           OpenDialog is class "opendlg"
           CharacterArray is class "chararry".
       working-storage section.
       01 wsOpenDialog             object reference.
       01 wsDesktop                object reference.
       01 wsEventManager           object reference.
       01 wsFilterName             object reference.
       01 wsFilter                 object reference.
       01 wsNullFilterName         object reference.
       01 wsNullFilter             object reference.
       01 wsDefaultFile            object reference.
       01 wsDefaultExt             object reference.
       01 wsFile                   object reference.
       01 wsFilenameLen            pic s9(9) comp-5.
       01 wsSize                   pic s9(9) comp-5.
       linkage section.
       01 lnkFilename              pic x(256).
       procedure division using lnkFilename.

           call "apigui"   *> Initialize the GUI Class Library

      *---- Start an EventManager so we can get a desktop reference

           invoke EventManager "new" returning wsEventManager
           invoke wsEventManager "initialize"
           invoke wsEventManager "getDesktop" returning wsDesktop

      *---- Create an Instance of the Open Files Dialog
           invoke OpenDialog "New"
              using wsDesktop
              returning wsOpenDialog
           end-invoke

      *---- Use *.tmp as a filter
           invoke CharacterArray "withValue"
              using z"Temp Files (*.tmp)"
              returning wsFilterName
           end-invoke
           invoke CharacterArray "withValue"
              using z"*.tmp"
              returning wsFilter
           end-invoke
           invoke wsOpenDialog "addFilter"
              using wsFiltername
                    wsFilter
           end-invoke
           invoke CharacterArray "withValue"
              using x"0000"
              returning wsNullFiltername
           end-invoke
           invoke CharacterArray "withValue"
              using x"0000"
              returning wsNullFilter
           end-invoke
           invoke wsOpenDialog "addFilter"
              using wsNullFiltername
                    wsNullFilter
           end-invoke

           invoke CharacterArray "withValue"
              using z".\*.tmp"
              returning wsDefaultFile
           end-invoke
           invoke wsOpenDialog "setFile"
              using wsDefaultFile
           end-invoke
           invoke CharacterArray "withValue"
              using z".tmp"
              returning wsDefaultExt
           end-invoke
           invoke wsOpenDialog "setExtension"
              using wsDefaultExt
           end-invoke
           invoke wsOpenDialog "setTitleZ"
              using z"Select File to Delete"
           end-invoke

           invoke wsOpenDialog "show"
      *----Retrieve information from dialog
           invoke wsOpenDialog "getFile"
              returning wsFile
           end-invoke
           if wsFile <> null
              invoke wsFile "getValue"
                 returning lnkFilename
              end-invoke
              invoke wsFile "sizeinbytes"
                 returning wsFilenameLen
              end-invoke
              move x"0000" to lnkFilename(wsFilenameLen + 1:2)
              invoke wsFile "finalize" returning wsFile
           else
              move spaces to lnkFilename
           end-if

           invoke wsOpenDialog "finalize" returning wsOpenDialog
           invoke wsDesktop "finalize" returning wsDesktop
           invoke wsEventManager "finalize" returning wsEventManager
           invoke wsFilterName "finalize" returning wsFilterName
           invoke wsFilter "finalize" returning wsFilter
           invoke wsNullFilterName "finalize" returning wsNullFilterName
           invoke wsNullFilter "finalize" returning wsNullFilter
           invoke wsDefaultFile "finalize" returning wsDefaultFile
           invoke wsDefaultExt "finalize" returning wsDefaultExt
           exit program.

