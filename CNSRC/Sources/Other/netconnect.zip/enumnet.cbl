      *----------------------------------------------------------------*
      *                         ENUMNET                                *
      *                                                                *
      *  This program demonstrates the use of the Windows SDK API calls*
      *  to return an array of current network connection information  *
      *  such as drive mappings and shared resources for your system.  *
      *  This sample returns information for all currently connected   *
      *  disk resources but can be modified to also return shared      *
      *  printer information and information on other drive resources  *
      *  which are not currently connected but are remembered.         *
      *                                                                *
      *  This example is currently setup to return information for up  *
      *  to 100 network connections. If you have more than this on your*
      *  system simply increase the number of occurrences of the       *
      *  NetResource data item.                                        *
      *                                                                *
      *  This sample loads the file MPR.DLL which is part of the       *
      *  operating system. This file must be available within the PATH *
      *  in order for this program to work correctly.                  *
      *  By default it should be within the Windows system directory.  *
      *----------------------------------------------------------------*
       id division.
       program-id.   enumnet.
       environment division.
       special-names.
          call-convention 66 is WINAPI.
       data division.
       working-storage section.
       copy "netvalue.cpy".
       78 PROGRAM-NAME                         value "ENUMNET".

      *** The Net Resource structure defined as an array.
      *** each occurrence holds info for one resource.
      *** This sample uses a max of 100 items but this can be larger.

       01 NetResourceArray.
          05 NetResource occurs 100 times.
             10 dwScope          pic s9(9) comp-5.
             10 dwType           pic s9(9) comp-5.
             10 dwDisplayType    pic s9(9) comp-5.
             10 dwUsage          pic s9(9) comp-5.
             10 lpLocalName      pointer.
             10 lpRemoteName     pointer.
             10 lpComment        pointer.
             10 lpProvider       pointer.

      *** connect-count can be set to the desired number of resources
      *** to be returned. Upon return from the call it will contain the
      *** number of resources that were actually returned.

       01 connect-count          pic s9(9) comp-5 value zeroes.
       01 lpBufferSize           pic s9(9) comp-5 value zeroes.
       01 ret-code               pic s9(9) comp-5.
       01 EnumHandle             pic s9(9) comp-5.

      *** These fields hold the returned string info. Actual info
      *** returned is a pointer to the value. This pointer is assigned
      *** linkage using the ret-param linkage section item. The values
      *** are them moved to these fields for display.

       01 wsLocalName            pic x(100)       value spaces.
       01 wsRemoteName           pic x(100)       value spaces.
       01 wsComment              pic x(100)       value spaces.
       01 wsProvider             pic x(100)       value spaces.

       01 sub-1                  pic 9(9) comp-5  value zeroes.
       01 any-key                pic x.
       01 dll-point              procedure-pointer.
       linkage section.
       01 ret-param              pic x(100). *>used for returned pointer
       procedure division.
       000-begin.

      ***  Start the process by getting an Enum handle for all network
      ***  disk resources that are currently connected.                                            t                                     ly active.

           set dll-point to entry "MPR.DLL".

           if dll-point = NULL
              display "Cannot Load MPR.DLL!"
              stop run
           end-if

           call WINAPI "WNetOpenEnumA"
              using by value RESOURCE-CONNECTED
                    by value RESOURCETYPE-DISK
                    by value 0
                    by value 0
                    by reference EnumHandle
              returning ret-code
           end-call

           if ret-code not = NO-ERROR
              display "Error calling WNetOpenEnum = " ret-code
              accept any-key
              stop run
           end-if

           move GET-ALL-CONNECTIONS to connect-count
      ***  Values returned as an array of NetResource structures.
           move length of NetResourceArray to lpBufferSize
           call WINAPI "WNetEnumResourceA"
              using by value EnumHandle
                    by reference connect-count
                    by reference NetResourceArray
                    by reference lpBufferSize
              returning ret-code
           end-call

      ***  If successful connect-count = number of resources returned.
      ***  Pointers returned are assigned linkage and the values are
      ***  moved to working-storage items for display.

           perform varying sub-1 from 1 by 1
              until sub-1 > connect-count
              move spaces to wsLocalName wsRemoteName wsComment
                 wsProvider
              if lpLocalName(sub-1) not = NULL
                 set address of ret-param to lpLocalName(sub-1)
                 unstring ret-param delimited by X"00"
                    into wsLocalName
                 end-unstring
              end-if
              if lpRemoteName(sub-1) not = NULL
                 set address of ret-param to lpRemoteName(sub-1)
                 unstring ret-param delimited by X"00"
                    into wsRemoteName
                 end-unstring
              end-if
              if lpComment(sub-1) not = NULL
                 set address of ret-param to lpComment(sub-1)
                 unstring ret-param delimited by X"00"
                    into wsComment
                 end-unstring
              end-if
              if lpProvider(sub-1) not = NULL
                 set address of ret-param to lpProvider(sub-1)
                 unstring ret-param delimited by X"00"
                    into wsProvider
                 end-unstring
              end-if
              display "Mapped Drive = " wsLocalName (1:20)
              display "Share Name   = " wsRemoteName (1:20)
              display "Comment      = " wsComment (1:20)
              display "Provider     = " wsProvider (1:20)
              accept any-key
            end-perform

            call WINAPI "WNetCloseEnum"
               using by value EnumHandle
               returning ret-code
            end-call
            display PROGRAM-NAME " : Ending"
            stop run.
