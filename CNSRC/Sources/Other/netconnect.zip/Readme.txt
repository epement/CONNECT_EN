   =========================================================================
                              Micro Focus
                              Net Express
   =========================================================================
                            PROJECT NETCONNECT
                            ==================

   DATE CREATED:         May 17, 2002
   =============

   BUILD W/RELEASE:      3.1
   ================

   TABLE OF CONTENTS
   =================
        INTRODUCTION
        SOURCE FILES
        REQUIREMENTS
        OPERATION

   INTRODUCTION
   ============
        This program demonstrates how to use the Windows 32-bit
        Network API functions to obtain a list of available network resources
        and their associated parameters. It also demonstrates how to map to
        a network drive and printer from within COBOL.

   SOURCE FILES:
   =============

        Program Files   Description
	=============	=============================================
        ENUMNET.CBL     Program that obtains information about all currently
                        connected network drives.

        MAPNET.CBL      Program that will map a local drive letter to a network
                        shared resource.

        NETVALUE.CPY    Copy file containing message and error constants used
                        by the Windows API functions.


   REQUIREMENTS:
   =============
        These samples should run in all network environments. In order to map
        a drive letter to a remote disk it must be defined as a shared resource.

        This sample loads the file MPR.DLL which is part of the operating
        system. This file must be available within the PATH in order for this
        program to work correctly. By default it should be within the Windows
        system directory.

   OPERATION:
   ==========
        Rebuild this project to create the files ENUMNET.EXE and MAPNET.EXE.
        These are both character mode programs.

   NOTE:
   =====

   =========================================================================
   Micro Focus and Net Express are registered trademarks of Micro Focus Inc.
=========================================================================
   Copyright (C) 1996-2001 Micro Focus Inc.
