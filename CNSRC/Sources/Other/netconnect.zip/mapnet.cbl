      *----------------------------------------------------------------*
      *                         MAPNET                                 *
      *                                                                *
      *  This program demonstrates the use of the Windows SDK API calls*
      *  to map a local drive letter to a shared resource on a differ- *
      *  ent machine on your network. The remote resource must be setup*
      *  as a shared resource in order for this sample to work.        *
      *                                                                *
      *  This call accepts a User Name and a Password parameter which  *
      *  work as follows:                                              *
      *                                                                *
      *  If lpPassword is NULL, the function uses the current default  *
      *  password associated with the user specified by lpUserName.    *
      *  If lpPassword points to an empty string, the function does not*
      *  use a password.                                               *
      *                                                                *
      *  lpUsername points to a null-terminated string that specifies  *
      *  a user name to be used in making the connection. If lpUserName*
      *  is NULL, the function uses the default user name. The user    *
      *  context for the process provides the default user name.       *
      *  The lpUserName parameter is specified when users want to      *
      *  connect to a network resource for which they have been        *
      *  assigned a user name or account other than the default user   *
      *  name or account.                                              *
      *                                                                *
      *  To run this sample simply change the LocalName, RemoteName,   *
      *  Username and Password parameters to values which are accepted *
      *  on your network and rebuild the project.                      *
      *                                                                *
      *  This sample loads the file MPR.DLL which is part of the       *
      *  operating system. This file must be available within the PATH *
      *  in order for this program to work correctly.                  *
      *  By default it should be within the Windows system directory.  *
      *----------------------------------------------------------------*
       id division.
       program-id.  mapnet.
       environment division.
       special-names.
          call-convention 66 is WINAPI.
       data division.
       working-storage section.
       copy "netvalue.cpy".
       78 PROGRAM-NAME                         value "MAPNET".

      *** LocalName contains the drive letter that you wish to map to
      *** the remote drive.

       01 LocalName              pic x(20)     value z"J:".

      *** RemoteName is the machine name and resource to which you wish
      *** to connect. The following will map the drive letter to the
      *** C drive of the computer with the name Laptop. This must be
      *** setup as a shared resource on the remote computer before you
      *** can map to it.

       01 RemoteName             pic x(20)     value z"\\Laptop\C".

      *** Use username and password of a user account.
      *** If this is passed as NULL then the default username and
      *** password will be used.

       01 lpUsername             pic x(20)     value z"Sam".
       01 lpPassword             pic x(20)     value z"mypass".

       01 dwFlags                pic s9(9) comp-5.

       01 NetResource.   *> structure as defined in Windows SDK
          05 dwScope             pic s9(9) comp-5.
          05 dwType              pic s9(9) comp-5.
          05 dwDisplayType       pic s9(9) comp-5.
          05 dwUsage             pic s9(9) comp-5.
          05 lpLocalName         pointer.
          05 lpRemoteName        pointer.
          05 lpComment           pointer.
          05 lpProvider          pointer.

       01 ret-code               pic s9(9) comp-5.
       01 dll-point              procedure-pointer.
       procedure division.
       000-begin.

           set dll-point to entry "MPR.DLL"
           if dll-point = NULL
              display "Cannot Load MPR.DLL!"
              stop run
           end-if

           display PROGRAM-NAME ": Starting"

      ***  We want to map to a disk drive.
      ***  You can also map to a printer by changing this parameter.

           move RESOURCETYPE-DISK to dwType

      ***  The following items in the passed NetResource structure must
      ***  be passed as pointers.

           set lpLocalName to address of LocalName
           set lpRemoteName to address of RemoteName
           set lpComment to NULL   *> Not used in this call
           set lpProvider to NULL  *> Not used in this call

      ***  You could set dwFlags to CONNECT-UPDATE-PROFILE in which case
      ***  the connection will be remembered and will be reconnected
      ***  during future logins. In this example this option is not set.

           move 0 to dwFlags

           call WINAPI "WNetAddConnection2A"
              using by reference NetResource
                                 lpPassword
      ***  Replace lpPassword by BY VALUE 0 if you wish to use default.
                                 lpUsername
      ***  Replace lpUsername by BY VALUE 0 if you wish to use default.
                    by value     dwFlags
              returning ret-code
           end-call

           if ret-code = NO-ERROR
              display "Network drive mapping successful!"
           else
              display "Error Occurred = " ret-code
              *> Check error constants in working-storage.
           end-if

           display PROGRAM-NAME ": Ending"
           stop run.
