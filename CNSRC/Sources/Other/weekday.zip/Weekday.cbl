      $ set Ans85 NoOsvs NoVsc2 NoQual DefaultByte"00"
       78  programName             value 'Weekday'.
       linkage section.
       1   gregorianDate pic 9(8). *> YYYYMMDD
       procedure division using by reference gregorianDate.
           move FUNCTION INTEGER-OF-DATE (gregorianDate) to RETURN-CODE
           if RETURN-CODE = 0 *> Invalid Gregorian date!
             move -1 to RETURN-CODE
           else
             move FUNCTION REM (RETURN-CODE 7) to RETURN-CODE
           end-if
           exit program
           stop run.
