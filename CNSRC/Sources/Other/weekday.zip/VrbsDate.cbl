      $ set Ans85 NoOsvs NoVsc2 NoQual DefaultByte"00"
       special-names. call-convention 8 is cc8.
       working-storage section.
       78  programName               value 'VrbsDate'.
       1   weekDayValues.
       2   filler          pic x(10) value 'Sunday    '.
       2   filler          pic x(10) value 'Monday    '.
       2   filler          pic x(10) value 'Tuesday   '.
       2   filler          pic x(10) value 'Wednesday '.
       2   filler          pic x(10) value 'Thursday  '.
       2   filler          pic x(10) value 'Friday    '.
       2   filler          pic x(10) value 'Saturday  '.
       1   weekDay redefines weekDayValues occurs 7 times pic x(10).
       1   monthValues.
       2   filler          pic x(10) value 'January   '.
       2   filler          pic x(10) value 'February  '.
       2   filler          pic x(10) value 'March     '.
       2   filler          pic x(10) value 'April     '.
       2   filler          pic x(10) value 'May       '.
       2   filler          pic x(10) value 'June      '.
       2   filler          pic x(10) value 'July      '.
       2   filler          pic x(10) value 'August    '.
       2   filler          pic x(10) value 'September '.
       2   filler          pic x(10) value 'October   '.
       2   filler          pic x(10) value 'November  '.
       2   filler          pic x(10) value 'December  '.
       1   yearMonth redefines monthValues occurs 12 times pic x(10).
       1   stringPointer   pic x comp-x.
       linkage section.
       1   gregorianDate. *> YYYYMMDD
       2   gregorianYear   pic 9999.
       2   gregorianMonth  pic 99.
       2   gregorianDay    pic 99.
       1   verboseDateRecord.
       2   verboseLength   pic x   comp-x.
       2   verboseDate     pic x(30).
       procedure division using by reference gregorianDate
                                by reference verboseDateRecord.
           call cc8 'WeekDay' using by reference gregorianDate
           if RETURN-CODE <> -1
             move SPACES to verboseDate
             move 1 to stringPointer
             string weekDay(RETURN-CODE + 1)   delimited by SPACE
                    ', '                       delimited by size
                    yearMonth(gregorianMonth)  delimited by SPACE
                    ', '                       delimited by size
                    gregorianDay               delimited by size
                    ', '                       delimited by size
                    gregorianYear              delimited by size
               into verboseDate
               with pointer stringPointer
             subtract 1 from stringPointer giving verboseLength
           end-if
           exit program
           stop run.
