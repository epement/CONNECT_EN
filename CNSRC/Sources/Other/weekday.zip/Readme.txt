============================================================
                        M E R A N T
                    N E T E X P R E S S
============================================================
                      PROJECT Weekday
                      ===============

DATE CREATED:     April 2001
=============

BUILD W/RELEASE:  NetExpress 3.1
================

TABLE OF CONTENTS
=================
    INTRODUCTION
    SOURCE FILES
    PROGRAMMING

INTRODUCTION
============
Using intrinsic functions to validate Gregorian dates and 
create a date such as "Monday, April, 09, 2001".

SOURCE FILES:
=============
     Program Files   Description
     =============   =======================================
     Calendar.cbl    A main program that requires a 
                     "verbose" date. The date should have 
                     the names of week days and months with 
                     the week day, month, numeric day and 
                     numeric year separated by commas. This 
                     program generates potential Gregorian 
                     dates calling upon VrbsDate for a 
                     verbose version of the date.

     VrbsDate.cbl    A sub program that calls upon the 
                     Weekday program for a validation of 
                     the Gregorian date provided by the 
                     caller, and a week day number. If the 
                     Gregorian date is valid VrbsDate 
                     assembles a verbose date.

     Weekday.cbl     A sub program that uses the intrinsic 
                     function INTEGER-OF-DATE to convert 
                     the Gregorian date provided into the 
                     number of days by which the date 
                     succeeds December 31, 1600, in the 
                     Gregorian calendar. If the Gregorian 
                     date is invalid the function returns 
                     zero which is converted to a -1 return 
                     value for the Weekday program. When 
                     the date is valid the remainder of the 
                     converted date, divideded by 7, is 
                     returned as the week day number, where 
                     zero equals Sunday, one equals Monday, 
                     two equals Tuesday, etc.

PROGRAMMING:
============
The Calendar program uses the OutDD compiler directive to 
divert displayed output to a text file named Calendar.txt. 
This file is created within the Project directory and can 
be edited with NetExpress. 

RETURN-CODE is used to pass around both valid data, the 
numeric week day number ( 0 through 6), and an error code 
of "-1". 

pwm 4/9/2001