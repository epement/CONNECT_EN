      $ set Ans85 NoOsvs NoVsc2 NoQual DefaultByte"00"
      $ set OutDD"Calendar.txt 80 L A"
       special-names. call-convention 8 is cc8.
       working-storage section.
       78  programName                 value 'Calendar'.
       1   gregorianDate . *> YYYYMMDD
       2   gregorianYear   pic 9999.
       2   gregorianMonth  pic 99.
       2   gregorianDay    pic 99.
       1   verboseDateRecord.
       2   verboseLength   pic x   comp-x.
       2   verboseDate     pic x(30).
       1   validDate.
       3   filler          pic x(8)    value programName.
       3   filler          pic x(17)   value ': Gregorian Date '.
       3   goodDate        pic 9(8).
       3   filler          pic x       value SPACE.
       3   longDate        pic x(30).
       1   invalidDate.
       3   filler          pic x(8)    value programName.
       3   filler          pic x(17)   value ': Gregorian Date '.
       3   badDate         pic 9(8).
       3   filler          pic x(12)   value ' is invalid.'.
       procedure division.
           display programName ': Starting.'
           move 2002 to gregorianYear
      *    move 2 to gregorianMonth
      *    move 31 to gregorianDay
           perform with test after varying gregorianMonth from 1 by 1
               until GregorianMonth = 12
             perform with test after varying gregorianDay from 1 by 1
                 until gregorianDay = 31
               call cc8 'VrbsDate' using by reference gregorianDate
                                         by reference verboseDateRecord
               if RETURN-CODE <> -1
                 move gregorianDate to goodDate
                 move verboseDate to longDate
                 display validDate
               else
                 move gregorianDate to badDate
                 display invalidDate
               end-if
             end-perform
           end-perform
           display programName ': Ending.'
           exit program
           stop run.
